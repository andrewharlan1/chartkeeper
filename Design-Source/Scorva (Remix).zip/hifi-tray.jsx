/* global React, InstrumentIcon */
// ============================================================
// Scorva HI-FI: Upload tray (Notion rows × Linear) + migration picker (Things)
// ============================================================

function PdfPill() {
  return <div className="pdf-pill">PDF</div>;
}

function SlotPill({ slot, icon, unsure = false, score = false, onClick }) {
  if (unsure) {
    return (
      <span className="slot-pill unsure" onClick={onClick}>
        <InstrumentIcon slot="unknown" size={16} />
        <span>pick slot…</span>
        <span className="caret">▾</span>
      </span>
    );
  }
  return (
    <span className={"slot-pill" + (score ? " score-slot" : "")} onClick={onClick}>
      <InstrumentIcon slot={icon || slot} size={16} />
      <span>{slot}</span>
      <span className="caret">▾</span>
    </span>
  );
}

function MigButton({ value, open = false, onClick }) {
  const empty = !value || value === "—";
  return (
    <button className={"mig-button" + (open ? " open" : "")} onClick={onClick}>
      <span className="label">migrate from</span>
      <span className="val" style={{ marginLeft: 6 }}>
        {empty ? <span className="dim" style={{ fontWeight: 400 }}>none</span> : value}
      </span>
      <span className="caret">▾</span>
    </button>
  );
}

function ScoreToggle({ on = false, onClick }) {
  return (
    <span className={"score-toggle" + (on ? " on" : "")} onClick={onClick}>
      <span className="box">
        {on ? (
          <svg width="9" height="9" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M2 5.5 L4.2 7.5 L8 3" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        ) : null}
      </span>
      score
    </span>
  );
}

// ============================================================
// Upload Tray
// ============================================================
function HfUploadTray({
  files,
  version = "v2",
  onMigrationOpen,
  openIndex = -1,
  publishLabel,
  carryForward,
  midDrag = false,
  target = "new",       // "new" -> new version (v_n+1) | "current" -> add to current
  currentVersion,        // e.g. "v3"  (only used when target === "current")
  onTarget,
}) {
  const isCurrent = target === "current";
  const targetVer = isCurrent ? (currentVersion || "v3") : version;
  const willText = isCurrent
    ? `ADD TO ${targetVer.toUpperCase()} · NO NEW VERSION`
    : `WILL CREATE ${version.toUpperCase()}`;
  return (
    <div className="tray">
      <div className="head">
        <div className="title">
          {midDrag && <span className="pulse" />}
          {midDrag ? `Reading ${files.length} PDFs…` : "Upload"}
        </div>
        <div className="meta">
          {files.length} FILE{files.length !== 1 ? "S" : ""} · {willText}
        </div>
        <div className="right">
          <button className="btn ghost sm">Cancel</button>
        </div>
      </div>

      <div className="target-bar">
        <span className="label">Where does this go?</span>
        <div className="seg">
          <button
            className={isCurrent ? "on" : ""}
            onClick={() => onTarget && onTarget("current")}
          >
            Add to current <span className="v">{currentVersion || "v3"}</span>
          </button>
          <button
            className={!isCurrent ? "on" : ""}
            onClick={() => onTarget && onTarget("new")}
          >
            Publish as new <span className="v">{version}</span>
          </button>
        </div>
        <div className="hint">
          {isCurrent
            ? <>fixing an upload · players see <b>no version bump</b></>
            : <>composer changes · players get <b>{version} migration banner</b></>
          }
        </div>
      </div>

      <div className="tray-body">
        {files.map((f, i) => (
          <div className={"tray-row" + (f.kind === "score" ? " score-flagged" : "")} key={i}>
            <PdfPill />
            <div className="filecell">
              <div style={{ minWidth: 0, flex: 1 }}>
                <div className="filename">{f.file}</div>
                <div className="filesize">{f.size || "—"}</div>
              </div>
            </div>
            <div className="arrow">→</div>
            <div>
              <SlotPill
                slot={f.slot}
                icon={f.icon}
                unsure={f.unsure}
                score={f.kind === "score"}
              />
            </div>
            <div>
              <MigButton
                value={f.migration}
                open={openIndex === i}
                onClick={() => onMigrationOpen && onMigrationOpen(i)}
              />
            </div>
            <div>
              <ScoreToggle on={f.kind === "score"} />
            </div>
          </div>
        ))}
      </div>

      {carryForward && carryForward.length > 0 && (
        <div className="carry-strip">
          <span className="icons">
            {carryForward.map((c, i) => (
              <InstrumentIcon key={i} slot={c.icon} size={16} />
            ))}
          </span>
          <span>
            <b style={{ color: "var(--ink)", fontWeight: 500 }}>
              {carryForward.map((c) => c.slot).join(", ")}
            </b>{" "}
            carries forward unchanged. No upload needed.
          </span>
        </div>
      )}

      <div className="tray-foot">
        <input
          className="name-input"
          placeholder="(optional) name this version — e.g. recording session draft"
        />
        <span className="grow" />
        <span className="dim mono" style={{ fontSize: 11 }}>auto-named: {version}</span>
        <button className="btn primary">{publishLabel || (isCurrent ? `Add to ${targetVer}` : `Publish ${version}`)}</button>
      </div>
    </div>
  );
}

// ============================================================
// Migration source picker (Things 3 / Cmd-K)
// ============================================================
function HfMigrationPicker({ x = 600, y = 280, partLabel = "Violin 1", chosen = "Cello · v1" }) {
  const opts = [
    {
      group: "Same part — previous versions",
      items: [
        { icon: "violin", label: "Violin 1 · v1", meta: "didn't exist", disabled: true },
      ],
    },
    {
      group: "Sibling parts — any version",
      items: [
        { icon: "cello", label: "Cello · v1", meta: "3 annotations", current: true },
        { icon: "viola", label: "Viola · v1", meta: "didn't exist", disabled: true },
      ],
    },
    {
      group: "Or",
      items: [
        { icon: "none", label: "No migration", meta: "clean part" },
      ],
    },
  ];

  return (
    <div className="mig-pop" style={{ left: x, top: y }}>
      <div className="search">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ color: "var(--ink-3)" }}>
          <circle cx="6" cy="6" r="4" />
          <path d="M9 9 L12 12" strokeLinecap="round" />
        </svg>
        <input defaultValue="cell" placeholder={`Migrate annotations into ${partLabel} from…`} />
        <span className="esc-hint">esc</span>
      </div>

      {opts.map((g, gi) => (
        <React.Fragment key={gi}>
          <div className="group-label">{g.group}</div>
          {g.items.map((o, oi) => (
            <div
              key={oi}
              className={"opt" + (o.current ? " cur" : "") + (o.disabled ? " disabled" : "")}
            >
              <span className="icon">
                {o.icon === "none" ? (
                  <span style={{ width: 16, height: 16, display: "inline-block" }} />
                ) : (
                  <InstrumentIcon slot={o.icon} size={16} />
                )}
              </span>
              <span className="label">{o.label}</span>
              <span className="meta">{o.meta}</span>
            </div>
          ))}
        </React.Fragment>
      ))}

      <div className="footer">
        <span><span className="kbd">↑</span> <span className="kbd">↓</span> navigate</span>
        <span><span className="kbd">↵</span> select</span>
        <span style={{ marginLeft: "auto" }}>default: previous version of this part</span>
      </div>
    </div>
  );
}

window.HfUploadTray = HfUploadTray;
window.HfMigrationPicker = HfMigrationPicker;
window.SlotPill = SlotPill;
window.MigButton = MigButton;
