// Resting state — chart page with upload affordance present but inactive.
// Two variants exposed: empty (fresh chart) and populated (v1 with parts).

function RestingState({ variant = "populated" }) {
  const v1Parts = [
    { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score.pdf" },
    { slot: "Trumpet 1", icon: "trumpet", file: "tpt1.pdf" },
    { slot: "Trumpet 2", icon: "trumpet", file: "tpt2.pdf" },
    { slot: "Alto Sax 1", icon: "sax", file: "as1.pdf" },
    { slot: "Tenor Sax", icon: "sax", file: "ts.pdf" },
    { slot: "Piano", icon: "piano", file: "pno.pdf" },
    { slot: "Bass", icon: "bass", file: "bs.pdf" },
    { slot: "Drums", icon: "drums", file: "drm.pdf" },
  ];

  return (
    <div className="frame wf">
      <AppBar />
      <div className="app-shell">
        <Sidebar />
        <div className="main">
          <div className="main-inner">
            <ChartHeader version="v1" versions={["v1"]} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginTop: 4 }}>
              <h2 className="section">Parts</h2>
              <span className="mono dim" style={{ fontSize: 11 }}>
                {variant === "populated" ? "8 of 8 slots filled" : "0 of 8 slots filled"}
              </span>
            </div>
            <PartsList parts={variant === "populated" ? v1Parts : []} />
            <DropZone />
            <div className="mono dim" style={{ fontSize: 11, marginTop: -6 }}>
              Tip — drop anywhere on this page. Scorva will route to slots.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.RestingState = RestingState;
