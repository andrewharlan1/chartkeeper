/* global React, InstrumentIcon, HfSidebar, HfTopBar, ChartHead, HfPartsList, DropZone */

// Three palette variants of resting-A (the editorial-table direction).
// Structure is identical to HfFrameResting; only design tokens shift via wrapper class.

const RESTING_PARTS = [
  { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score_v3.pdf",
    versionsCount: 3, statusKind: "changed", statusLabel: "v3 · updated",
    migrationSource: "—", historyBadge: true },
  { slot: "Cello", icon: "cello", file: "cello_v1.pdf",
    versionsCount: 3, statusKind: "carried", statusLabel: "carried forward",
    migrationSource: "—", historyBadge: false },
  { slot: "Violin 1", icon: "violin", file: "violin1_v3.pdf",
    versionsCount: 3, statusKind: "changed", statusLabel: "v3 · 4 measures",
    migrationSource: "Violin 1 v2", historyBadge: true },
  { slot: "Viola", icon: "viola", file: "viola_v3.pdf",
    versionsCount: 3, statusKind: "changed", statusLabel: "v3 · 1 measure",
    migrationSource: "Viola v2", historyBadge: true },
];

function PalettedResting({ paletteAttr, calloutLabel, calloutText }) {
  return (
    <div className="hf" data-pal={paletteAttr}>
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar
            right={
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <button className="btn ghost sm">Share</button>
                <button className="btn sm">Add part</button>
              </div>
            }
          />
          <div className="hf-content">
            <div className="hf-inner">
              <ChartHead
                version="v3"
                versions={["v3", "v2", "v1"]}
                partsCount={4}
                whenText="pushed Tue · 2 parts changed since v2"
                rightActions={
                  <>
                    <button className="btn ghost sm">View diff</button>
                    <button className="btn ghost sm">Settings</button>
                  </>
                }
              />
              <HfPartsList parts={RESTING_PARTS} />
              <DropZone />
              <div className="note-callout">
                <div className="l">{calloutLabel}</div>
                {calloutText}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function HfRestingPalAubergine() {
  return (
    <PalettedResting
      paletteAttr="aubergine"
      calloutLabel="Palette · aubergine & sage"
      calloutText={<>Cool plum paper, deep aubergine ink, sage-green accent for change. Reads like a music-publisher catalogue — Spectral display serif, IBM Plex Mono for system text. Calmer than warm-orange; less startup-y, more editorial.</>}
    />
  );
}

function HfRestingPalMidnight() {
  return (
    <PalettedResting
      paletteAttr="midnight"
      calloutLabel="Palette · midnight blueprint"
      calloutText={<>Dark mode. Charcoal-blue paper, off-white ink, electric cyan accent. Studio/console feel — fits late-night composer/director sessions and high-glare iPad rooms. JetBrains Mono throughout for the schematic blueprint look.</>}
    />
  );
}

function HfRestingPalBone() {
  return (
    <PalettedResting
      paletteAttr="bone"
      calloutLabel="Palette · bone & ember"
      calloutText={<>High-contrast bone paper, near-black ink, ember red accent. Italic Playfair display serif. Architectural and serious — feels like sheet-music engraving and program notes, less like a SaaS app.</>}
    />
  );
}

window.HfRestingPalAubergine = HfRestingPalAubergine;
window.HfRestingPalMidnight = HfRestingPalMidnight;
window.HfRestingPalBone = HfRestingPalBone;
