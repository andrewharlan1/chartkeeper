/* global React, InstrumentIcon, HfSidebar, HfTopBar, ChartHead, HfPartsList,
   DropZone, HfUploadTray, HfMigrationPicker, HfPlayerView, HfHistory,
   HfDiffLog, HfPublishConfirm, MigrationBanner, ScorePage */

// ============================================================
// Hi-fi frames — one per moment, using the shared shell.
// ============================================================

// ---------- 01. Resting state ----------
function HfFrameResting() {
  const parts = [
    {
      slot: "Score", icon: "score", kind: "score",
      file: "lunar-noon-score_v3.pdf",
      versionsCount: 3,
      statusKind: "changed",
      statusLabel: "v3 · updated",
      migrationSource: "—",
      historyBadge: true,
    },
    {
      slot: "Cello", icon: "cello",
      file: "cello_v1.pdf",
      versionsCount: 3,
      statusKind: "carried",
      statusLabel: "carried forward",
      migrationSource: "—",
      historyBadge: false,
    },
    {
      slot: "Violin 1", icon: "violin",
      file: "violin1_v3.pdf",
      versionsCount: 3,
      statusKind: "changed",
      statusLabel: "v3 · 4 measures",
      migrationSource: "Violin 1 v2",
      historyBadge: true,
    },
    {
      slot: "Viola", icon: "viola",
      file: "viola_v3.pdf",
      versionsCount: 3,
      statusKind: "changed",
      statusLabel: "v3 · 1 measure",
      migrationSource: "Viola v2",
      historyBadge: true,
    },
  ];

  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar
            right={
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <span className="dim mono" style={{ fontSize: 11 }}>auto-saves on push</span>
                <button className="btn ghost sm">Share</button>
                <button className="btn sm">Add part</button>
              </div>
            }
          />
          <div className="hf-content">
            <div className="hf-inner">
              <ChartHead
                version="v3"
                versions={["v3", "v2", "v1"]}
                partsCount={4}
                whenText="pushed Tue · 2 parts changed since v2"
                rightActions={
                  <>
                    <button className="btn ghost sm">View diff</button>
                    <button className="btn ghost sm">Settings</button>
                  </>
                }
              />
              <HfPartsList parts={parts} />
              <DropZone />
              <div className="note-callout">
                <div className="l">Resting state</div>
                Drop zone is quiet but addressable. Each row's History pill ({" "}
                <span className="mono" style={{ background: "var(--card)", padding: "1px 5px", borderRadius: 3, border: "1px solid var(--line)" }}>v3</span>
                {" "}with an orange dot) is the entry point into per-part timelines. No version-name field — director never has to type "v3."
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 02. Tray mid-drag (Scenario 2) ----------
function HfFrameTrayMidDrag() {
  const [target, setTarget] = React.useState("new");
  const files = [
    { file: "violin1.pdf", size: "1.24 MB", slot: "Violin 1", icon: "violin", migration: "Cello · v1" },
    { file: "viola.pdf", size: "1.18 MB", slot: "Viola", icon: "viola", migration: "Cello · v1" },
    { file: "lunar-noon-score.pdf", size: "3.42 MB", slot: "Score", icon: "score", kind: "score", migration: "—" },
  ];
  const carryForward = [{ slot: "Cello", icon: "cello" }];

  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar />
          <div className="hf-content" style={{ background: "var(--paper)" }}>
            <div className="hf-inner">
              <ChartHead
                version="v1"
                versions={["v1"]}
                partsCount={1}
                whenText={target === "current" ? "adding to v1" : "dropped 3 PDFs · cello carries forward"}
                working={target === "current"}
              />
              <HfUploadTray
                files={files}
                version="v2"
                currentVersion="v1"
                target={target}
                onTarget={setTarget}
                carryForward={target === "new" ? carryForward : null}
                midDrag={true}
              />
              <div className="note-callout">
                <div className="l">Scenario 2 · adding parts</div>
                <b>The drop asks: new version or fix to current?</b> Default for unpublished v1 is "Publish as new" — composer is making v2. Toggle to "Add to current" and the same files get folded into v1 with no version bump (no migration banner, no diff log entry). The tray hint changes to reflect the consequences for players.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 02b. Add part to current version ----------
function HfFrameAddToCurrent() {
  const [target, setTarget] = React.useState("current");
  const files = [
    { file: "viola_FINAL_final.pdf", size: "1.18 MB", slot: "Viola", icon: "viola", migration: "—" },
  ];

  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar />
          <div className="hf-content" style={{ background: "var(--paper)" }}>
            <div className="hf-inner">
              <ChartHead
                version="v3"
                versions={["v3", "v2", "v1"]}
                partsCount={3}
                whenText={target === "current" ? "patching v3 · forgot viola" : "publishing v4"}
                working={target === "current"}
              />
              <HfUploadTray
                files={files}
                version="v4"
                currentVersion="v3"
                target={target}
                onTarget={setTarget}
                midDrag={false}
              />
              <div className="note-callout">
                <div className="l">"I forgot to upload viola"</div>
                Director realizes v3 was published without viola. They drop the file, see the chooser, pick <b>Add to current v3</b>. No new version, no banner on players' iPads, no diff entry — viola simply appears on v3. The chart header shows v3 in <span style={{ color: "var(--accent)" }}>working</span> mode (pulsing dot) until the upload completes. This is the load-bearing distinction between <i>fixing</i> and <i>composing</i>.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 03A. Migration picker — inline ----------
function HfFrameMigInline() {
  const files = [
    { file: "violin1.pdf", size: "1.24 MB", slot: "Violin 1", icon: "violin", migration: "Cello · v1" },
    { file: "viola.pdf", size: "1.18 MB", slot: "Viola", icon: "viola", migration: "Cello · v1" },
    { file: "lunar-noon-score.pdf", size: "3.42 MB", slot: "Score", icon: "score", kind: "score", migration: "—" },
  ];

  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar />
          <div className="hf-content" style={{ position: "relative" }}>
            <div className="hf-inner">
              <ChartHead
                version="v1 → v2"
                versions={["v1"]}
                partsCount={1}
                whenText="picking migration source for violin 1"
              />
              <HfUploadTray
                files={files}
                version="v2"
                carryForward={[{ slot: "Cello", icon: "cello" }]}
                openIndex={0}
              />
              <div style={{ position: "relative", height: 0 }}>
                <HfMigrationPicker x={585} y={-216} partLabel="Violin 1" chosen="Cello · v1" />
              </div>
              <div className="note-callout" style={{ marginTop: 60 }}>
                <div className="l">A · inline picker</div>
                Picker hangs off the row's "migrate from" cell · keyboard-first (typed "cell", arrow keys, ↵ to commit). Sibling parts grouped, disabled options dimmed with the reason inline. Default selection is highlighted.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 03B. Migration picker — separate review step ----------
function HfFrameMigSeparate() {
  const rows = [
    {
      part: "Violin 1", icon: "violin", file: "violin1.pdf",
      sources: [
        { label: "Cello · v1", meta: "3 annotations", current: true, icon: "cello" },
        { label: "No migration", meta: "clean part" },
      ],
    },
    {
      part: "Viola", icon: "viola", file: "viola.pdf",
      sources: [
        { label: "Cello · v1", meta: "3 annotations", current: true, icon: "cello" },
        { label: "No migration", meta: "clean part" },
      ],
    },
  ];

  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar trail="Configure migrations" />
          <div className="hf-content">
            <div className="hf-inner">
              <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 8 }}>
                <span className="mono dim" style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase" }}>Step 2 of 2</span>
                <span className="mono dim" style={{ fontSize: 11 }}>· upload → migrate → publish</span>
              </div>
              <h1 style={{ fontFamily: "var(--serif)", fontWeight: 500, fontSize: 30, margin: "0 0 10px", letterSpacing: "-0.025em" }}>
                Configure migrations
              </h1>
              <p className="dim" style={{ margin: "0 0 22px", fontSize: 14, lineHeight: 1.5, maxWidth: 620 }}>
                Each new part can pull annotations from a source. Defaults shown. Players can override per-annotation later.
              </p>

              <div className="parts-card">
                <div className="ph" style={{ gridTemplateColumns: "28px 1fr 1.4fr 100px" }}>
                  <span></span>
                  <span>New part</span>
                  <span>Migrate from</span>
                  <span style={{ textAlign: "right" }}>Annot.</span>
                </div>
                {rows.map((r, i) => (
                  <div className="part-row" key={i} style={{ gridTemplateColumns: "28px 1fr 1.4fr 100px" }}>
                    <span className="icon-cell">
                      <InstrumentIcon slot={r.icon} size={22} />
                    </span>
                    <span className="name-cell">
                      <span className="name">{r.part}</span>
                      <span className="filename">{r.file}</span>
                    </span>
                    <span style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                      {r.sources.map((s, si) => (
                        <span
                          key={si}
                          style={{
                            display: "flex", alignItems: "center", gap: 8,
                            padding: "5px 10px",
                            borderRadius: 6,
                            background: s.current ? "var(--highlight)" : "transparent",
                            border: s.current ? "1px solid var(--highlight-2)" : "1px solid transparent",
                            fontSize: 13,
                          }}
                        >
                          {s.icon ? <InstrumentIcon slot={s.icon} size={14} /> : <span style={{ width: 14, display: "inline-block" }} />}
                          <span style={{ fontWeight: s.current ? 500 : 400, color: s.current ? "var(--ink)" : "var(--ink-3)" }}>{s.label}</span>
                          <span style={{ marginLeft: "auto", fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-4)" }}>{s.meta}</span>
                          {s.current && <span style={{ marginLeft: 6, fontFamily: "var(--mono)", fontSize: 10, color: "var(--accent)" }}>default</span>}
                        </span>
                      ))}
                    </span>
                    <span style={{ textAlign: "right", fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-3)" }}>
                      3
                    </span>
                  </div>
                ))}
              </div>

              <div style={{ display: "flex", gap: 10, marginTop: 22, justifyContent: "flex-end" }}>
                <button className="btn ghost">‹ Back to upload</button>
                <button className="btn primary">Publish v2 →</button>
              </div>

              <div className="note-callout">
                <div className="l">B · separate review step</div>
                Same picker logic, more deliberate. Better for batches with many guesses; worse for the common case where defaults are right and the director just wants to publish. <b>Recommend A</b> as default, B as a fallback path when 5+ files need migration decisions.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 04. Score upload + preview ----------
function HfFrameScoreUpload() {
  const files = [
    { file: "violin1.pdf", size: "1.24 MB", slot: "Violin 1", icon: "violin", migration: "Cello · v1" },
    { file: "lunar-noon-score.pdf", size: "3.42 MB", slot: "Score", icon: "score", kind: "score", migration: "—" },
  ];

  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar />
          <div className="hf-content">
            <div className="hf-inner">
              <ChartHead version="v1 → v2" versions={["v1"]} partsCount={1} whenText="score detected · light clarification needed" />
              <div className="tray">
                <div className="head">
                  <div className="title">
                    <span className="pulse" /> Reading 2 PDFs…
                  </div>
                  <div className="meta">2 FILES · WILL CREATE V2</div>
                </div>

                {/* Score preview row — hover-expanded version of a tray-row */}
                <div className="score-tray-preview">
                  <div className="thumb">
                    {[0, 1, 2].map((sys) => (
                      <React.Fragment key={sys}>
                        {[0, 1, 2, 3, 4].map((i) => (
                          <div className="line" key={i} />
                        ))}
                        <div className="gap" />
                      </React.Fragment>
                    ))}
                    <div className="pn">p. 1 / 18</div>
                  </div>
                  <div className="meta">
                    <div className="l">Detected · conductor's score · 4 staves</div>
                    <h4>lunar-noon-score.pdf</h4>
                    <div style={{ fontSize: 12.5, color: "var(--ink-3)", marginBottom: 4 }}>
                      Scorva read the title block. Confirm or change before publish.
                    </div>
                    <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-3)", marginTop: 10, marginBottom: 4 }}>which instruments are in this score?</div>
                    <div className="chips">
                      {[
                        { s: "Cello", on: true, icon: "cello" },
                        { s: "Violin 1", on: true, icon: "violin" },
                        { s: "Viola", on: true, icon: "viola" },
                      ].map((c) => (
                        <span key={c.s} className={"chip" + (c.on ? " on" : "")}>
                          <InstrumentIcon slot={c.icon} size={12} />
                          {c.s} {c.on && "✓"}
                        </span>
                      ))}
                      <span className="chip" style={{ color: "var(--ink-4)", fontStyle: "italic" }}>+ add</span>
                    </div>
                  </div>
                </div>

                {/* Other regular row (the violin 1 part) — no expanded preview */}
                <div className="tray-body">
                  <div className="tray-row">
                    <div className="pdf-pill">PDF</div>
                    <div className="filecell">
                      <div style={{ minWidth: 0, flex: 1 }}>
                        <div className="filename">violin1.pdf</div>
                        <div className="filesize">1.24 MB</div>
                      </div>
                    </div>
                    <div className="arrow">→</div>
                    <div>
                      <span className="slot-pill">
                        <InstrumentIcon slot="violin" size={16} />
                        <span>Violin 1</span>
                        <span className="caret">▾</span>
                      </span>
                    </div>
                    <div>
                      <button className="mig-button">
                        <span className="label">migrate from</span>
                        <span className="val" style={{ marginLeft: 6 }}>Cello · v1</span>
                        <span className="caret" style={{ marginLeft: "auto", color: "var(--ink-4)" }}>▾</span>
                      </button>
                    </div>
                    <div>
                      <span className="score-toggle">
                        <span className="box" />
                        score
                      </span>
                    </div>
                  </div>
                </div>

                <div className="tray-foot">
                  <input className="name-input" placeholder="(optional) name this version" />
                  <span style={{ flex: 1 }} />
                  <button className="btn primary">Publish v2</button>
                </div>
              </div>

              <div className="note-callout">
                <div className="l">Score handling</div>
                Score isn't a separate flow — it's a row in the same tray with its <span className="mono" style={{ background: "var(--card)", padding: "1px 5px", borderRadius: 3, border: "1px solid var(--line)" }}>score ✓</span> toggle on by default and an inline preview thumbnail. Clarifying questions live next to the preview, not in a modal.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 05. Publish confirm ----------
function HfFramePublishConfirm() {
  // Show the chart page slightly behind, with the modal centered.
  const parts = [
    { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score_v2.pdf", versionsCount: 2, statusKind: "changed", statusLabel: "v2 · updated", historyBadge: true },
    { slot: "Cello", icon: "cello", file: "cello_v1.pdf", versionsCount: 1, statusKind: "carried", statusLabel: "carried forward" },
    { slot: "Violin 1", icon: "violin", file: "violin1.pdf", versionsCount: 1, statusKind: "added", statusLabel: "v2 · added", historyBadge: true, migrationSource: "Cello v1" },
    { slot: "Viola", icon: "viola", file: "viola.pdf", versionsCount: 1, statusKind: "added", statusLabel: "v2 · added", historyBadge: true, migrationSource: "Cello v1" },
  ];
  return (
    <div className="hf" style={{ position: "relative" }}>
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar />
          <div className="hf-content">
            <div className="hf-inner" style={{ filter: "blur(2px)", opacity: 0.6 }}>
              <ChartHead version="v2" versions={["v2", "v1"]} partsCount={4} whenText="just now" />
              <HfPartsList parts={parts} />
            </div>
          </div>
        </div>
      </div>
      <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        <HfPublishConfirm />
      </div>
    </div>
  );
}

// ---------- 06A. Player view — persistent banner ----------
function HfFramePlayerPersistent() {
  return <HfPlayerView variant="persistent" />;
}

// ---------- 06B. Player view — toast ----------
function HfFramePlayerToast() {
  return <HfPlayerView variant="toast" />;
}

// ---------- 07. History timeline opened ----------
function HfFrameHistory() {
  return (
    <div className="hf">
      <div style={{ height: "100%", display: "grid", gridTemplateColumns: "240px 1fr" }}>
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar trail="Violin 1 · history" />
          <div style={{ flex: 1, overflow: "hidden" }}>
            <HfHistory partLabel="Violin 1" current="v3" />
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 08. v4 with cello removed ----------
function HfFrameV4Removed() {
  // Active first, removed last (the auto-sink behavior locked in earlier).
  const parts = [
    { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score_v4.pdf", versionsCount: 4, statusKind: "changed", statusLabel: "v4 · updated", historyBadge: true },
    { slot: "Violin 1", icon: "violin", file: "violin1_v3.pdf", versionsCount: 3, statusKind: "carried", statusLabel: "carried forward", historyBadge: false },
    { slot: "Viola", icon: "viola", file: "viola_v3.pdf", versionsCount: 3, statusKind: "carried", statusLabel: "carried forward", historyBadge: false },
    { slot: "Cello", icon: "cello", file: "—", versionsCount: 3, statusKind: "removed", statusLabel: "removed in v4" },
  ];

  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar />
          <div className="hf-content">
            <div className="hf-inner">
              <ChartHead
                version="v4"
                versions={["v4", "v3", "v2", "v1"]}
                partsCount={3}
                whenText="v3 → v4 · removed Cello"
                rightActions={
                  <>
                    <button className="btn ghost sm">View diff</button>
                    <button className="btn ghost sm">Hide removed (1)</button>
                  </>
                }
              />
              <HfPartsList parts={parts} />
              <div className="note-callout">
                <div className="l">Removed parts auto-sink</div>
                Cello dropped to the bottom, struck-through, dimmed — out of the active reading order but still has its history. Hide-removed toggle in the chart header collapses it entirely. Players who had Cello see a "this part is no longer in the chart" banner on next sync.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- bonus: standalone diff log card ----------
function HfFrameDiffLog() {
  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar trail="Violin 1 · diff · v2 → v3" />
          <div className="hf-content">
            <div className="hf-inner">
              <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 8 }}>
                <span className="mono dim" style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase" }}>Diff · violin 1 · v2 → v3</span>
              </div>
              <h1 style={{ fontFamily: "var(--serif)", fontWeight: 500, fontSize: 30, margin: "0 0 6px", letterSpacing: "-0.025em" }}>
                4 measures changed
              </h1>
              <p className="dim" style={{ margin: "0 0 22px", fontSize: 14 }}>
                Anchored at <span className="mono">m.17 · m.18 · m.34</span>. Annotations were re-anchored automatically — players see only the controls in their migration banner.
              </p>
              <HfDiffLog file="violin1.pdf · v3" />

              <div style={{ marginTop: 28 }}>
                <h3 style={{ fontFamily: "var(--serif)", fontWeight: 500, fontSize: 20, margin: "0 0 12px", letterSpacing: "-0.02em" }}>
                  In context
                </h3>
                <div style={{ background: "var(--card)", border: "1px solid var(--line)", borderRadius: 14, overflow: "hidden", height: 360 }}>
                  <ScorePage withDiff={true} withAnnotations={false} partLabel="Violin 1" version="v3" />
                </div>
              </div>

              <div className="note-callout">
                <div className="l">PR-style diff</div>
                File-level grouping, "X measures changed" summary header, color-coded rows for adds/removes/mods, expand/collapse on long stretches of unchanged content. Anchors at top let the director jump straight to the change.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Exports
window.HfFrameResting = HfFrameResting;
window.HfFrameTrayMidDrag = HfFrameTrayMidDrag;
window.HfFrameAddToCurrent = HfFrameAddToCurrent;
window.HfFrameMigInline = HfFrameMigInline;
window.HfFrameMigSeparate = HfFrameMigSeparate;
window.HfFrameScoreUpload = HfFrameScoreUpload;
window.HfFramePublishConfirm = HfFramePublishConfirm;
window.HfFramePlayerPersistent = HfFramePlayerPersistent;
window.HfFramePlayerToast = HfFramePlayerToast;
window.HfFrameHistory = HfFrameHistory;
window.HfFrameV4Removed = HfFrameV4Removed;
window.HfFrameDiffLog = HfFrameDiffLog;
