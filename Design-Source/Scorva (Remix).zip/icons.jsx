// Instrument icon set in the style of the provided sample (1.7 stroke, rounded, currentColor).
// These are sketched approximations matching the visual vocabulary; swap with real assets later.

const SvgBase = ({ children, size = 28, style = {} }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 28 28"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.7"
    strokeLinecap="round"
    strokeLinejoin="round"
    style={style}
  >
    {children}
  </svg>
);

// The provided sample (clarinet/sax-ish bell with keys).
const IconClarinet = (p) => (
  <SvgBase {...p}>
    <path d="M9 3.5C6 3.5 4 6 4 9.5C4 12.5 6 13.8 9 14.5C6 15.2 4 16.5 4 19.5C4 23 6 25.5 9 25.5C11 26 17 26 19 25.5C22 25.5 24 23 24 19.5C24 16.5 22 15.2 19 14.5C22 13.8 24 12.5 24 9.5C24 6 22 3.5 19 3.5C17 3 11 3 9 3.5Z" />
    <line x1="14" y1="3.5" x2="14" y2="0.5" strokeWidth="2.3" />
    <line x1="14" y1="25.5" x2="14" y2="28.5" />
    <line x1="10.5" y1="9.5" x2="10.5" y2="20" strokeWidth="0.9" />
    <line x1="17.5" y1="9.5" x2="17.5" y2="20" strokeWidth="0.9" />
    <line x1="9.5" y1="14.5" x2="18.5" y2="14.5" strokeWidth="1.3" />
  </SvgBase>
);

const IconTrumpet = (p) => (
  <SvgBase {...p}>
    <path d="M2 14 L18 14" />
    <path d="M18 9 L26 9 L26 19 L18 19 Z" />
    <line x1="9" y1="11" x2="9" y2="14" strokeWidth="0.9" />
    <line x1="13" y1="11" x2="13" y2="14" strokeWidth="0.9" />
    <line x1="17" y1="11" x2="17" y2="14" strokeWidth="0.9" />
    <circle cx="3" cy="14" r="1.2" />
  </SvgBase>
);

const IconSax = (p) => (
  <SvgBase {...p}>
    <path d="M14 3 L14 14 C14 19 11 22 7 22 C4 22 3 20 3 17 C3 14 5 13 7 14" />
    <path d="M14 14 C18 14 21 17 22 21 L25 25" />
    <line x1="13" y1="2" x2="15" y2="4" strokeWidth="2" />
    <circle cx="11" cy="9" r="0.6" />
    <circle cx="11" cy="13" r="0.6" />
  </SvgBase>
);

const IconCello = (p) => (
  <SvgBase {...p}>
    <path d="M14 4 C10 4 8 6 8 9 C8 11 10 12 11 13 C9 14 6 16 6 20 C6 23 9 25 14 25 C19 25 22 23 22 20 C22 16 19 14 17 13 C18 12 20 11 20 9 C20 6 18 4 14 4 Z" />
    <line x1="14" y1="4" x2="14" y2="25" strokeWidth="0.9" />
    <line x1="11" y1="3" x2="11" y2="6" />
    <line x1="17" y1="3" x2="17" y2="6" />
  </SvgBase>
);

const IconViolin = (p) => (
  <SvgBase {...p}>
    <path d="M14 3 C11 3 10 5 10 8 C10 10 11 11 11 12 C9 13 7 15 7 18 C7 22 10 25 14 25 C18 25 21 22 21 18 C21 15 19 13 17 12 C17 11 18 10 18 8 C18 5 17 3 14 3 Z" />
    <line x1="14" y1="3" x2="14" y2="25" strokeWidth="0.9" />
    <line x1="12" y1="14" x2="16" y2="14" strokeWidth="0.6" />
    <line x1="12" y1="17" x2="16" y2="17" strokeWidth="0.6" />
  </SvgBase>
);

const IconPiano = (p) => (
  <SvgBase {...p}>
    <rect x="3" y="7" width="22" height="14" />
    <line x1="9" y1="7" x2="9" y2="17" />
    <line x1="14" y1="7" x2="14" y2="17" />
    <line x1="19" y1="7" x2="19" y2="17" />
    <rect x="6.5" y="7" width="2" height="6" fill="currentColor" stroke="none" />
    <rect x="11.5" y="7" width="2" height="6" fill="currentColor" stroke="none" />
    <rect x="16.5" y="7" width="2" height="6" fill="currentColor" stroke="none" />
    <rect x="21" y="7" width="2" height="6" fill="currentColor" stroke="none" />
  </SvgBase>
);

const IconBass = (p) => (
  <SvgBase {...p}>
    <path d="M14 3 C9 3 6 7 6 13 C6 19 9 25 14 25 C19 25 22 19 22 13 C22 7 19 3 14 3 Z" />
    <circle cx="14" cy="15" r="2.5" />
    <line x1="14" y1="3" x2="14" y2="12" strokeWidth="0.7" />
    <line x1="11" y1="6" x2="17" y2="6" strokeWidth="0.7" />
  </SvgBase>
);

const IconDrums = (p) => (
  <SvgBase {...p}>
    <ellipse cx="14" cy="9" rx="9" ry="3" />
    <path d="M5 9 L5 18 C5 20 9 21 14 21 C19 21 23 20 23 18 L23 9" />
    <line x1="8" y1="11" x2="6" y2="24" />
    <line x1="20" y1="11" x2="22" y2="24" />
  </SvgBase>
);

const IconGuitar = (p) => (
  <SvgBase {...p}>
    <path d="M14 14 C10 14 7 17 7 21 C7 24 9 26 12 26 C15 26 17 24 17 21" />
    <path d="M17 21 L20 9 L23 6 L25 8 L22 11 L17 14" />
    <circle cx="12" cy="20" r="1.5" />
  </SvgBase>
);

const IconScore = (p) => (
  <SvgBase {...p}>
    <path d="M5 4 L21 4 L23 6 L23 25 L5 25 Z" />
    <line x1="8" y1="9" x2="20" y2="9" strokeWidth="0.6" />
    <line x1="8" y1="12" x2="20" y2="12" strokeWidth="0.6" />
    <line x1="8" y1="15" x2="20" y2="15" strokeWidth="0.6" />
    <line x1="8" y1="18" x2="20" y2="18" strokeWidth="0.6" />
    <line x1="8" y1="21" x2="20" y2="21" strokeWidth="0.6" />
    <circle cx="11" cy="14" r="1" fill="currentColor" stroke="none" />
    <circle cx="15" cy="17" r="1" fill="currentColor" stroke="none" />
  </SvgBase>
);

const IconUnknown = (p) => (
  <SvgBase {...p}>
    <rect x="5" y="5" width="18" height="18" strokeDasharray="2 2" />
    <text x="14" y="18" textAnchor="middle" fontSize="11" fontFamily="ui-monospace, monospace" fill="currentColor" stroke="none">?</text>
  </SvgBase>
);

window.SCORVA_ICONS = {
  clarinet: IconClarinet,
  trumpet: IconTrumpet,
  sax: IconSax,
  alto: IconSax,
  tenor: IconSax,
  cello: IconCello,
  violin: IconViolin,
  viola: IconViolin,
  piano: IconPiano,
  bass: IconBass,
  drums: IconDrums,
  guitar: IconGuitar,
  score: IconScore,
  unknown: IconUnknown,
};

window.InstrumentIcon = function InstrumentIcon({ slot, size = 22, style }) {
  const key = (slot || "").toLowerCase();
  const Icon =
    window.SCORVA_ICONS[key] ||
    Object.entries(window.SCORVA_ICONS).find(([k]) => key.includes(k))?.[1] ||
    window.SCORVA_ICONS.unknown;
  return <Icon size={size} style={style} />;
};
