/* global React, InstrumentIcon, HfSidebar, HfTopBar */
// ============================================================
// Ensemble landing page — all charts in this ensemble + roster
// (instruments + members). Card-style grid above, roster below.
// ============================================================

const ENSEMBLE = {
  name: "String Trio + Score",
  cadence: "Tuesdays · Aoki Hall",
  conductor: "Helen Aoki",
  members: [
    { instrument: "Cello",    icon: "cello",  name: "Marta Iglesias", role: "principal", since: "2022", initials: "MI", color: "#7a8ba8" },
    { instrument: "Violin 1", icon: "violin", name: "Daniel Wei",     role: "principal", since: "2023", initials: "DW", color: "#c8531c" },
    { instrument: "Viola",    icon: "viola",  name: "June Ortiz",     role: "principal", since: "2024", initials: "JO", color: "#5e7548" },
  ],
  // The "Score" lane is implicit (the conductor); not a member, but listed at the top of the roster.
};

const CHARTS = [
  {
    id: "lunar-noon",
    title: "Lunar Noon",
    composer: "H. Aoki",
    version: "v3",
    parts: 4,
    when: "pushed Tue",
    changes: 2,
    status: "active",
    sparks: [10, 14, 18],
    note: "2 parts changed since v2",
    isCurrent: true,
  },
  {
    id: "equinox",
    title: "Equinox",
    composer: "H. Aoki",
    version: "v2",
    parts: 4,
    when: "pushed Apr 18",
    changes: 0,
    status: "active",
    sparks: [9, 12, 12],
    note: "all parts current",
  },
  {
    id: "open-air",
    title: "Open Air",
    composer: "H. Aoki",
    version: "v1",
    parts: 2,
    when: "draft · 2 of 4 parts",
    changes: 0,
    status: "draft",
    sparks: [6, 6, 6],
    note: "missing Violin 1, Viola",
  },
  {
    id: "salt-flats",
    title: "Salt Flats",
    composer: "M. Iglesias",
    version: "v4",
    parts: 4,
    when: "pushed Apr 09",
    changes: 0,
    status: "active",
    sparks: [8, 12, 14, 16],
    note: "performed Apr 12 · ready",
  },
  {
    id: "blue-marker",
    title: "Blue Marker",
    composer: "D. Wei",
    version: "v2",
    parts: 4,
    when: "pushed Mar 28",
    changes: 1,
    status: "active",
    sparks: [11, 11, 14],
    note: "Viola · 2 measures",
  },
  {
    id: "north-station",
    title: "North Station",
    composer: "H. Aoki",
    version: "v1",
    parts: 4,
    when: "archived Feb 12",
    changes: 0,
    status: "archived",
    sparks: [10, 10, 10],
    note: "no recent activity",
  },
];

function HfChartCard({ chart, onClick }) {
  return (
    <button className={"chart-card " + chart.status + (chart.isCurrent ? " current" : "")} type="button" onClick={onClick}>
      <div className="cc-thumb">
        <div className="cc-thumb-page">
          {[0, 1, 2].map(s => (
            <div className="cc-system" key={s}>
              {[0, 1, 2, 3, 4].map(l => <div className="cc-line" key={l} />)}
            </div>
          ))}
        </div>
        <div className="cc-thumb-corner">
          {chart.status === "draft" && <span className="cc-tag">draft</span>}
          {chart.status === "archived" && <span className="cc-tag">archived</span>}
          {chart.status === "active" && chart.changes > 0 && (
            <span className="cc-tag changed">{chart.changes} changed</span>
          )}
        </div>
      </div>
      <div className="cc-body">
        <div className="cc-row1">
          <h3 className="cc-title">{chart.title}</h3>
          <span className="cc-ver">{chart.version}</span>
        </div>
        <div className="cc-meta">
          <span>{chart.composer}</span>
          <span className="dot">·</span>
          <span>{chart.parts} parts</span>
        </div>
        <div className="cc-foot">
          <div className="cc-spark">
            {chart.sparks.map((h, i) => (
              <span
                className={"b" + (i === chart.sparks.length - 1 ? " cur" : "")}
                style={{ height: h }}
                key={i}
              />
            ))}
          </div>
          <span className="cc-when">{chart.when}</span>
        </div>
        <div className="cc-note">{chart.note}</div>
      </div>
    </button>
  );
}

function HfNewChartCard() {
  return (
    <button className="chart-card new" type="button">
      <div className="cc-newinner">
        <div className="cc-newicon">
          <svg width="20" height="20" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M8 3 L8 13 M3 8 L13 8" strokeLinecap="round" />
          </svg>
        </div>
        <div className="cc-newlabel">New chart</div>
        <div className="cc-newhint">drop a PDF or ⌘ N</div>
      </div>
    </button>
  );
}

function HfRosterRow({ member }) {
  return (
    <div className="roster-row">
      <div className="rr-instrument">
        <span className="icn"><InstrumentIcon slot={member.icon} size={20} /></span>
        <span className="lbl">{member.instrument}</span>
      </div>
      <div className="rr-member">
        <span className="rr-avatar" style={{ background: member.color }}>{member.initials}</span>
        <div className="rr-name-block">
          <div className="rr-name">{member.name}</div>
          <div className="rr-role">{member.role} · since {member.since}</div>
        </div>
      </div>
      <div className="rr-actions">
        <button className="btn ghost tiny">Re-assign</button>
        <button className="btn ghost tiny">Mute</button>
      </div>
    </div>
  );
}

function HfFrameEnsembleLanding() {
  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar ensemble={ENSEMBLE.name} chart="" />
        <div className="hf-main">
          {/* Custom topbar — no chart trail, ensemble is the "page" */}
          <div className="hf-topbar">
            <div className="hf-crumbs">
              <span className="cur">{ENSEMBLE.name}</span>
            </div>
            <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }}>
              <button className="btn ghost sm">Settings</button>
              <button className="btn sm">New chart</button>
            </div>
          </div>
          <div className="hf-content">
            <div className="hf-inner">
              {/* Hero */}
              <div className="ensemble-hero">
                <div className="eh-left">
                  <div className="eh-eyebrow">Ensemble</div>
                  <h1 className="eh-title">{ENSEMBLE.name}</h1>
                  <div className="eh-sub">
                    {ENSEMBLE.cadence} <span className="dot">·</span> conducted by {ENSEMBLE.conductor}
                  </div>
                </div>
                <div className="eh-stats">
                  <div className="eh-stat">
                    <div className="num">{CHARTS.filter(c => c.status === "active").length}</div>
                    <div className="lbl">active charts</div>
                  </div>
                  <div className="eh-stat">
                    <div className="num">{ENSEMBLE.members.length + 1}</div>
                    <div className="lbl">members <span className="ghost">(+ score)</span></div>
                  </div>
                  <div className="eh-stat">
                    <div className="num">{CHARTS.reduce((a, c) => a + (c.changes || 0), 0)}</div>
                    <div className="lbl">parts changed this week</div>
                  </div>
                </div>
              </div>

              {/* Section: Charts */}
              <div className="ensemble-section">
                <div className="es-head">
                  <h2 className="es-title">Charts</h2>
                  <div className="es-tabs">
                    <button className="es-tab active">All <span className="ct">{CHARTS.length}</span></button>
                    <button className="es-tab">Active <span className="ct">{CHARTS.filter(c => c.status === "active").length}</span></button>
                    <button className="es-tab">Draft <span className="ct">{CHARTS.filter(c => c.status === "draft").length}</span></button>
                    <button className="es-tab">Archived <span className="ct">{CHARTS.filter(c => c.status === "archived").length}</span></button>
                  </div>
                  <div className="es-tools">
                    <button className="btn ghost sm">Sort: recent ▾</button>
                  </div>
                </div>

                <div className="charts-grid">
                  {CHARTS.map(c => (
                    <HfChartCard chart={c} key={c.id} />
                  ))}
                  <HfNewChartCard />
                </div>
              </div>

              {/* Section: Roster */}
              <div className="ensemble-section">
                <div className="es-head">
                  <h2 className="es-title">Roster &amp; instruments</h2>
                  <div className="es-tools">
                    <button className="btn ghost sm">Add member</button>
                    <button className="btn ghost sm">Add instrument</button>
                  </div>
                </div>

                <div className="roster-card">
                  {/* Score row — implicit, listed first */}
                  <div className="roster-row score-row">
                    <div className="rr-instrument">
                      <span className="icn"><InstrumentIcon slot="score" size={20} /></span>
                      <span className="lbl">
                        Conductor's Score
                        <span className="rr-tag">SCORE LANE</span>
                      </span>
                    </div>
                    <div className="rr-member">
                      <span className="rr-avatar conductor">HA</span>
                      <div className="rr-name-block">
                        <div className="rr-name">{ENSEMBLE.conductor}</div>
                        <div className="rr-role">conductor · ensemble owner</div>
                      </div>
                    </div>
                    <div className="rr-actions">
                      <button className="btn ghost tiny">Open</button>
                    </div>
                  </div>

                  {ENSEMBLE.members.map(m => (
                    <HfRosterRow member={m} key={m.instrument} />
                  ))}

                  <button className="roster-add" type="button">
                    <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6">
                      <path d="M8 3 L8 13 M3 8 L13 8" strokeLinecap="round" />
                    </svg>
                    <span>Add an instrument · invite a member</span>
                  </button>
                </div>
              </div>

              <div className="note-callout" style={{ marginTop: 22 }}>
                <div className="l">Ensemble landing</div>
                Top-level page above charts. Card grid mirrors B's resting-state vocabulary so directors switch contexts without re-learning. Roster stays close — instrument first, member second — and the score lane is explicit so it can never be a forgotten dimension.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.HfFrameEnsembleLanding = HfFrameEnsembleLanding;
