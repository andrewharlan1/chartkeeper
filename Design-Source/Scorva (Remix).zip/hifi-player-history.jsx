/* global React, InstrumentIcon */
// ============================================================
// Scorva HI-FI: Player view (forScore × Superhuman) + History rail (Docs)
// ============================================================

function ScorePage({ withDiff = false, withAnnotations = true, partLabel = "Violin 1", version = "v2", measureFocus }) {
  return (
    <div className="score-page">
      <div className="score-title">
        Lunar Noon · {partLabel} · {version}
      </div>

      {[0, 1, 2, 3].map((sysI) => {
        const startMeasure = sysI * 8 + 1;
        const isFocusedSystem = withDiff && (startMeasure <= 17 && startMeasure + 7 >= 17);
        return (
          <div className="score-system" key={sysI} style={{ marginBottom: 28, position: "relative" }}>
            <span className="clef">𝄞</span>
            <span className="score-measure-num" style={{ left: 26 }}>{startMeasure}</span>
            {[0, 1, 2, 3, 4].map((li) => (
              <div className="score-line" key={li} style={{ marginLeft: 24, opacity: 0.65 }} />
            ))}
            {/* Bar lines (decoration) */}
            <div style={{ position: "absolute", left: 24, right: 0, top: 0, bottom: 0, pointerEvents: "none" }}>
              {[0.2, 0.4, 0.6, 0.8].map((p, i) => (
                <div
                  key={i}
                  style={{
                    position: "absolute",
                    left: `${p * 100}%`, top: 1, bottom: 1,
                    width: 1, background: "var(--ink)", opacity: 0.55,
                  }}
                />
              ))}
            </div>

            {/* Note glyphs (decorative — small filled circles on staff lines to suggest engraved music) */}
            {sysI === 0 && [
              { x: 0.06, y: 16 }, { x: 0.12, y: 11 }, { x: 0.20, y: 14 },
              { x: 0.28, y: 8 }, { x: 0.34, y: 11 }, { x: 0.46, y: 6 },
              { x: 0.55, y: 10 }, { x: 0.62, y: 14 }, { x: 0.74, y: 8 },
              { x: 0.82, y: 12 }, { x: 0.91, y: 16 },
            ].map((n, i) => (
              <div
                key={i}
                style={{
                  position: "absolute",
                  left: `calc(24px + ${n.x * 100}%)`, top: n.y,
                  width: 7, height: 5, borderRadius: "50%",
                  background: "var(--ink)",
                  transform: "rotate(-12deg)",
                }}
              />
            ))}
            {sysI === 1 && [
              { x: 0.04, y: 14 }, { x: 0.10, y: 8 }, { x: 0.18, y: 12 },
              { x: 0.26, y: 6 }, { x: 0.34, y: 10 }, { x: 0.42, y: 14 },
            ].map((n, i) => (
              <div
                key={i}
                style={{
                  position: "absolute",
                  left: `calc(24px + ${n.x * 100}%)`, top: n.y,
                  width: 7, height: 5, borderRadius: "50%",
                  background: "var(--ink)",
                  transform: "rotate(-12deg)",
                }}
              />
            ))}

            {/* Diff overlays — measure 17 area on system 2 (sysI=1) */}
            {withDiff && sysI === 1 && (
              <>
                <div
                  style={{
                    position: "absolute",
                    left: "calc(24px + 16% - 4px)", top: -4,
                    width: 70, height: 32,
                    background: "rgba(181,130,0,0.16)",
                    border: "1px solid rgba(181,130,0,0.5)",
                    borderRadius: 4,
                    pointerEvents: "none",
                  }}
                />
                <span className="diff-pill-inline" style={{ left: "calc(24px + 16%)", top: -22 }}>
                  m.17 · changed
                </span>
              </>
            )}

            {/* Annotations — cresc + text on system 1 */}
            {withAnnotations && sysI === 0 && (
              <>
                <div className="annotation-cresc" style={{ left: "30%", top: 20 }}>
                  <svg viewBox="0 0 180 18" preserveAspectRatio="none">
                    <line x1="2" y1="2" x2="178" y2="9" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round" />
                    <line x1="2" y1="16" x2="178" y2="9" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </div>
                <span className="annotation-text" style={{ left: "44%", top: 36 }}>cresc.</span>
              </>
            )}
            {withAnnotations && sysI === 2 && (
              <span className="annotation-text" style={{ left: "12%", top: -8, fontSize: 16 }}>watch tempo</span>
            )}
          </div>
        );
      })}

      {/* Page footer */}
      <div style={{
        position: "absolute", bottom: 18, left: 56, right: 56,
        display: "flex", justifyContent: "space-between",
        fontFamily: "var(--mono)", fontSize: 10, color: "var(--ink-4)",
      }}>
        <span>page 1 of 4</span>
        <span>{partLabel.toLowerCase().replace(/ /g, "")}.pdf</span>
      </div>
    </div>
  );
}

function MigrationBanner({ count = 3, source = "Cello v1", variant = "persistent" }) {
  if (variant === "toast") {
    return (
      <div className="toast-banner">
        <div className="icon-wrap" style={{
          width: 32, height: 32, borderRadius: 999,
          background: "var(--ok-soft)", border: "1.5px solid var(--ok)", color: "var(--ok)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6">
            <path d="M3 7 a4 4 0 0 1 8 0" />
            <path d="M11 7 L13 5 M11 7 L9 5" strokeLinecap="round" />
          </svg>
        </div>
        <div className="body">
          <div className="t">{count} annotations migrated from {source}</div>
          <div className="sub">First open · review now or anytime in Settings.</div>
        </div>
        <div style={{ display: "flex", gap: 6, marginLeft: 10 }}>
          <button className="b" style={{ padding: "5px 11px", fontSize: 12, border: "1px solid var(--line)", borderRadius: 6, background: "white", cursor: "pointer", fontWeight: 500 }}>Review</button>
          <button className="b primary" style={{ padding: "5px 11px", fontSize: 12, border: "1px solid var(--ink)", borderRadius: 6, background: "var(--ink)", color: "var(--paper)", cursor: "pointer", fontWeight: 500 }}>Keep all</button>
        </div>
        <span className="x">×</span>
      </div>
    );
  }
  return (
    <div className="mig-banner">
      <div className="icon-wrap">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M3 8 a5 5 0 0 1 10 0" />
          <path d="M13 8 L15 6 M13 8 L11 6" strokeLinecap="round" />
        </svg>
      </div>
      <div className="body">
        <div className="t">{count} annotations migrated from {source}</div>
        <div className="sub">Director's proposal. You have final say — keep, hide, delete, or change source per annotation.</div>
      </div>
      <div className="actions">
        <button className="b primary">Keep all</button>
        <button className="b">Hide</button>
        <button className="b">Delete</button>
        <button className="b">Change source ▾</button>
      </div>
    </div>
  );
}

function HfPlayerView({ variant = "persistent", showDiff = false, partLabel = "Violin 1", version = "v2" }) {
  return (
    <div className="player-frame">
      <div className="ipad-shell">
        <div className="ipad-screen">
          <div className="ipad-bar">
            <span className="crumb">‹ Lunar Noon</span>
            <span style={{ color: "var(--ink-4)" }}>·</span>
            <span className="cur-part">
              <InstrumentIcon slot="violin" size={14} />
              {partLabel}
            </span>
            <span className="ver-pill">{version}</span>
            <span className="grow" />
            <div className="right">
              <span>opened by Marta</span>
              <span style={{ width: 1, height: 14, background: "var(--line)" }} />
              <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
                <span style={{ width: 6, height: 6, borderRadius: 999, background: "var(--ok)" }} />
                synced
              </span>
            </div>
          </div>

          {variant === "persistent" && <MigrationBanner variant="persistent" />}

          <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
            <ScorePage withDiff={showDiff} partLabel={partLabel} version={version} />
            {variant === "toast" && <MigrationBanner variant="toast" />}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// History rail (Google Docs revision history × Linear)
// ============================================================
function HfHistory({ partLabel = "Violin 1", current = "v3" }) {
  const entries = [
    {
      v: "v4", when: "today · 2:14 PM", kind: "", desc: "no change in this part · cello removed from chart",
      isCurrent: false,
    },
    {
      v: "v3", when: "Tue · 4h ago", kind: "changed", desc: "4 measures changed · 7 annotations migrated from previous version",
      isCurrent: current === "v3", badge: "+7 annot",
    },
    {
      v: "v2", when: "Mon · 2 days ago", kind: "added", desc: "added · 3 annotations migrated from Cello v1",
      isCurrent: false,
    },
    {
      v: "v1", when: "—", kind: "ghost", desc: "Violin 1 didn't exist yet · chart was cello-only",
      isCurrent: false,
    },
  ];

  return (
    <div className="history-shell">
      <div className="history-preview">
        <div className="title">Showing · {partLabel} at {current}</div>
        <h2>Lunar Noon</h2>
        <ScorePage withDiff={true} withAnnotations={false} partLabel={partLabel} version={current} />
      </div>
      <div className="history-rail">
        <div className="title">Version history · {partLabel}</div>
        {entries.map((e, i) => (
          <div
            key={i}
            className={
              "h-entry " +
              (e.isCurrent ? "cur " : "") +
              (e.kind || "")
            }
          >
            <div className="dot-col">
              <div className="dot" />
              <div className="line" />
            </div>
            <div className="body">
              <div className="vlabel">
                {e.v}
                <span className="when">· {e.when}</span>
                {e.badge && (
                  <span
                    className="mono"
                    style={{
                      marginLeft: 8, fontSize: 10,
                      padding: "1px 6px", borderRadius: 999,
                      background: "var(--accent-soft)", color: "var(--accent)",
                    }}
                  >
                    {e.badge}
                  </span>
                )}
              </div>
              <div className="desc">{e.desc}</div>
            </div>
          </div>
        ))}
        <div style={{
          marginTop: 16, padding: "10px 12px",
          fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-4)",
          borderTop: "1px solid var(--line-2)",
        }}>
          history is per-part · scoped to {partLabel}
        </div>
      </div>
    </div>
  );
}

window.HfPlayerView = HfPlayerView;
window.HfHistory = HfHistory;
window.MigrationBanner = MigrationBanner;
window.ScorePage = ScorePage;
