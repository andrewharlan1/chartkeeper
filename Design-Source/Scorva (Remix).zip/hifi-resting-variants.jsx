/* global React, InstrumentIcon, HfSidebar, HfTopBar, ChartHead, HistoryButton, DropZone */

// ============================================================
// Resting-state variants — B (hero), B-hybrid, B-noscore, C, D
// ============================================================

// ---------- Shared parts data ----------
const REST_B_PARTS = [
  {
    id: "score", slot: "Conductor's Score", icon: "score", file: "lunar-noon-score_v3.pdf",
    kind: "score", changed: true, status: "v3 · updated", spark: [10, 14, 18],
    pages: 18, size: "4.82 MB",
    history: [
      { v: "v3", note: "updated · 4 measures", when: "Tue", cur: true },
      { v: "v2", note: "created", when: "Apr 14" },
      { v: "v1", note: "created", when: "Apr 02" },
    ],
    inspector: {
      anchorsLabel: "Anchors", anchors: "m.17 · 18 · 34",
      migratedFrom: "—", annotations: "all carried",
      statusColor: "var(--accent)", statusText: "4 measures changed",
    },
  },
  {
    id: "cello", slot: "Cello", icon: "cello", file: "cello_v1.pdf",
    kind: "part", changed: false, status: "carried forward", spark: [10, 10, 10],
    pages: 3, size: "0.87 MB",
    history: [
      { v: "v3", note: "carried forward", when: "Tue", cur: true },
      { v: "v2", note: "carried forward", when: "Apr 14" },
      { v: "v1", note: "created", when: "Apr 02" },
    ],
    inspector: {
      anchorsLabel: "Anchors", anchors: "all stable",
      migratedFrom: "Cello · v2", annotations: "12 carried",
      statusColor: "var(--ink-3)", statusText: "no changes",
    },
  },
  {
    id: "violin1", slot: "Violin 1", icon: "violin", file: "violin1_v3.pdf",
    kind: "part", changed: true, status: "v3 · 4 measures", spark: [7, 14, 18],
    pages: 3, size: "1.24 MB",
    history: [
      { v: "v3", note: "4 measures changed", when: "Tue", cur: true },
      { v: "v2", note: "created", when: "Apr 14" },
      { v: "v1", note: "n/a", when: "—", ghost: true },
    ],
    inspector: {
      anchorsLabel: "Anchors", anchors: "m.17 · 18 · 34",
      migratedFrom: "Violin 1 · v2", annotations: "7 re-anchored",
      statusColor: "var(--accent)", statusText: "4 measures changed",
    },
  },
  {
    id: "viola", slot: "Viola", icon: "viola", file: "viola_v3.pdf",
    kind: "part", changed: true, status: "v3 · 1 measure", spark: [6, 10, 12],
    pages: 2, size: "0.96 MB",
    history: [
      { v: "v3", note: "1 measure changed", when: "Tue", cur: true },
      { v: "v2", note: "created", when: "Apr 14" },
      { v: "v1", note: "created", when: "Apr 02" },
    ],
    inspector: {
      anchorsLabel: "Anchors", anchors: "m.34",
      migratedFrom: "Viola · v2", annotations: "3 carried",
      statusColor: "var(--accent)", statusText: "1 measure changed",
    },
  },
];

// ============================================================
// Sparkline + page-preview primitives (shared across B variants)
// ============================================================
function Spark({ values, accent = false }) {
  return (
    <div className="cc-spark inline">
      {values.map((h, i) => (
        <span
          className={"b" + (i === values.length - 1 ? " cur" : "")}
          style={{ height: h }}
          key={i}
        />
      ))}
    </div>
  );
}

function HfPagePreview({ kind, pageNo = 1, totalPages = 1, label, sub, accent }) {
  const isScore = kind === "score";
  const systems = isScore ? [0, 1, 2] : [0, 1, 2, 3];
  const stavesPerSystem = isScore ? 4 : 1;
  return (
    <div className="hf-preview">
      <div className="hp-bar">
        <span className="l">{label}</span>
        {accent && <span className="accent-pill">{accent}</span>}
        <span className="pn">p. {pageNo} / {totalPages} · {isScore ? "4 staves" : "1 staff"}</span>
      </div>
      <div className="hp-page">
        {systems.map((s, si) => (
          <div className={"hp-system" + (isScore ? "" : " single")} key={si}>
            {Array.from({ length: stavesPerSystem }).map((_, li) => (
              <div className="hp-staff" key={li}>
                {[0, 1, 2, 3, 4].map(k => <div className="hp-line" key={k} />)}
                {si === 1 && li === (isScore ? 2 : 0) && (
                  <div className="hp-marker" title="changed measure" />
                )}
              </div>
            ))}
          </div>
        ))}
        <div className="hp-pageno">— {pageNo} —</div>
      </div>
      <div className="hp-foot">
        <span>{sub}</span>
        <span style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
          <button className="btn ghost sm">Open ↗</button>
          <button className="btn sm">Replace ↑</button>
        </span>
      </div>
    </div>
  );
}

// Mini score thumb (used in part tiles & the hero)
function MiniScoreThumb({ kind = "part", changed = false }) {
  const isScore = kind === "score";
  const systems = isScore ? [0, 1, 2] : [0, 1, 2];
  const lines = isScore ? 4 : 1;
  return (
    <div className={"mini-thumb " + (isScore ? "score" : "part")}>
      {systems.map((_, si) => (
        <div className="mt-system" key={si}>
          {Array.from({ length: lines }).map((_, li) => (
            <div className="mt-staff" key={li}>
              {[0, 1, 2, 3, 4].map(k => <div className="mt-line" key={k} />)}
              {changed && si === 1 && li === (isScore ? 2 : 0) && <div className="mt-mark" />}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

// ============================================================
// B · ORIGINAL — score hero card + parts tiles below (no inspector)
// ============================================================
function HfRestingB() {
  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar
            right={
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <button className="btn ghost sm">Share</button>
                <button className="btn sm">Add part</button>
              </div>
            }
          />
          <div className="hf-content">
            <div className="hf-inner wide">
              <ChartHead
                version="v3"
                versions={["v3", "v2", "v1"]}
                partsCount={4}
                whenText="pushed Tue · 2 parts changed since v2"
              />

              {/* Hero: score card */}
              <article className="score-hero" tabIndex={0}>
                <div className="sh-thumb">
                  <MiniScoreThumb kind="score" changed />
                  <span className="sh-flag">v3 · 4 measures</span>
                </div>
                <div className="sh-body">
                  <div className="sh-eyebrow">Conductor's Score · the source</div>
                  <h2 className="sh-title">lunar-noon-score_v3.pdf</h2>
                  <div className="sh-meta">
                    <span>18 pages</span><span className="dot">·</span>
                    <span>4.82 MB</span><span className="dot">·</span>
                    <span>updated Tue</span>
                  </div>
                  <div className="sh-anchors">
                    <span className="lab">Anchors:</span>
                    <code>m.17</code><code>m.18</code><code>m.34</code>
                    <span className="muted">· all 4 parts re-aligned automatically</span>
                  </div>
                </div>
                <div className="sh-actions">
                  <button className="btn ghost sm">History</button>
                  <button className="btn sm">Open score ↗</button>
                </div>
              </article>

              {/* Parts tiles */}
              <div className="parts-tiles-head">
                <h3 className="ps-title">Parts</h3>
                <span className="ps-meta">3 of 4 changed since v2 · cello carried forward</span>
                <button className="ps-add" type="button">
                  <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6">
                    <path d="M8 3 L8 13 M3 8 L13 8" strokeLinecap="round" />
                  </svg>
                  <span>Add part</span>
                </button>
              </div>

              <div className="parts-tiles">
                {REST_B_PARTS.filter(p => p.kind !== "score").map(p => (
                  <article className={"part-tile" + (p.changed ? " changed" : " stable")} key={p.id}>
                    <header className="pt-head">
                      <span className="pt-icn"><InstrumentIcon slot={p.icon} size={20} /></span>
                      <span className="pt-name">{p.slot}</span>
                      <span className={"pt-status " + (p.changed ? "is-changed" : "is-stable")}>
                        {p.status}
                      </span>
                    </header>
                    <div className="pt-thumb">
                      <MiniScoreThumb kind="part" changed={p.changed} />
                    </div>
                    <footer className="pt-foot">
                      <span className="pt-file">{p.file}</span>
                      <Spark values={p.spark} />
                    </footer>
                  </article>
                ))}
              </div>

              <div className="note-callout" style={{ marginTop: 22 }}>
                <div className="l">B · score hero + parts tiles</div>
                The score is the source — it gets the wide hero card. Parts read as a tile row beneath, each carrying its own thumb, status pill, and a mini activity sparkline. No inspector — opening a part takes you into the chart's regular reading view.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// B-Hybrid · score hero + clickable expanding tiles + inspector
// ============================================================
function HfRestingBHybrid() {
  const PARTS = REST_B_PARTS.filter(p => p.kind !== "score");
  const [selectedId, setSelectedId] = React.useState("violin1");
  const [expandedId, setExpandedId] = React.useState("violin1");
  const selected = REST_B_PARTS.find(p => p.id === selectedId) || PARTS[0];
  const score = REST_B_PARTS[0];

  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar
            right={
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <button className="btn ghost sm">Share</button>
                <button className="btn sm">Add part</button>
              </div>
            }
          />
          <div className="hf-content">
            <div className="hf-inner wide-x">
              <ChartHead
                version="v3"
                versions={["v3", "v2", "v1"]}
                partsCount={4}
                whenText="pushed Tue · 2 parts changed since v2"
              />

              <div className="hybrid-grid">
                <div className="hg-main">
                  {/* Hero: score */}
                  <article
                    className={"score-hero clickable" + (selectedId === "score" ? " is-selected" : "")}
                    tabIndex={0}
                    onClick={() => setSelectedId("score")}
                  >
                    <div className="sh-thumb">
                      <MiniScoreThumb kind="score" changed />
                      <span className="sh-flag">v3 · 4 measures</span>
                    </div>
                    <div className="sh-body">
                      <div className="sh-eyebrow">Conductor's Score · the source</div>
                      <h2 className="sh-title">lunar-noon-score_v3.pdf</h2>
                      <div className="sh-meta">
                        <span>18 pages</span><span className="dot">·</span>
                        <span>4.82 MB</span><span className="dot">·</span>
                        <span>updated Tue</span>
                      </div>
                      <div className="sh-anchors">
                        <span className="lab">Anchors:</span>
                        <code>m.17</code><code>m.18</code><code>m.34</code>
                      </div>
                    </div>
                    <div className="sh-actions">
                      <button className="btn ghost sm" onClick={(e) => e.stopPropagation()}>History</button>
                      <button className="btn sm" onClick={(e) => e.stopPropagation()}>Open score ↗</button>
                    </div>
                  </article>

                  <div className="parts-tiles-head">
                    <h3 className="ps-title">Parts</h3>
                    <span className="ps-meta">click to preview · click again to expand inline</span>
                  </div>

                  <div className="parts-tiles hybrid">
                    {PARTS.map(p => {
                      const isSelected = p.id === selectedId;
                      const isExpanded = p.id === expandedId;
                      return (
                        <article
                          className={
                            "part-tile clickable" +
                            (p.changed ? " changed" : " stable") +
                            (isSelected ? " is-selected" : "") +
                            (isExpanded ? " is-expanded" : "")
                          }
                          key={p.id}
                          tabIndex={0}
                          onClick={() => {
                            if (selectedId === p.id) {
                              setExpandedId(isExpanded ? null : p.id);
                            } else {
                              setSelectedId(p.id);
                              setExpandedId(p.id);
                            }
                          }}
                        >
                          <header className="pt-head">
                            <span className="pt-icn"><InstrumentIcon slot={p.icon} size={20} /></span>
                            <span className="pt-name">{p.slot}</span>
                            <span className={"pt-status " + (p.changed ? "is-changed" : "is-stable")}>
                              {p.status}
                            </span>
                          </header>
                          <div className="pt-thumb">
                            <MiniScoreThumb kind="part" changed={p.changed} />
                          </div>
                          <footer className="pt-foot">
                            <span className="pt-file">{p.file}</span>
                            <Spark values={p.spark} />
                          </footer>
                          {isExpanded && (
                            <div className="pt-expand" onClick={(e) => e.stopPropagation()}>
                              <div className="pt-ex-head">
                                <span>{p.slot} · expanded preview</span>
                                <button
                                  className="btn ghost tiny"
                                  onClick={() => setExpandedId(null)}
                                  type="button"
                                >Collapse</button>
                              </div>
                              <div className="pt-ex-body">
                                <div className="pt-ex-thumb">
                                  <MiniScoreThumb kind="part" changed={p.changed} />
                                </div>
                                <div className="pt-ex-info">
                                  <div className="pt-ex-row"><span>Migrated from</span><span className="mono">{p.inspector.migratedFrom}</span></div>
                                  <div className="pt-ex-row"><span>Anchors</span><span className="mono">{p.inspector.anchors}</span></div>
                                  <div className="pt-ex-row"><span>Annotations</span><span className="mono">{p.inspector.annotations}</span></div>
                                  <div className="pt-ex-actions">
                                    <button className="btn ghost sm" type="button">Open diff</button>
                                    <button className="btn sm" type="button">Open part ↗</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </article>
                      );
                    })}
                  </div>
                </div>

                {/* Right inspector — always present */}
                <aside className="hg-inspector">
                  <div className="ir-head">
                    <div className="icn"><InstrumentIcon slot={selected.icon} size={22} /></div>
                    <div>
                      <div className="nm">{selected.slot}</div>
                      <div className="sub">{selected.kind === "score" ? "score · v3" : "selected · v3"}</div>
                    </div>
                  </div>

                  <div className="ir-section">
                    <div className="label">File</div>
                    <div className="ir-row"><span className="k">Filename</span><span className="v mono">{selected.file}</span></div>
                    <div className="ir-row"><span className="k">Size</span><span className="v mono">{selected.size}</span></div>
                    <div className="ir-row"><span className="k">Pages</span><span className="v mono">{selected.pages}</span></div>
                  </div>

                  <div className="ir-section">
                    <div className="label">This version</div>
                    <div className="ir-row"><span className="k">Status</span><span className="v" style={{ color: selected.inspector.statusColor }}>{selected.inspector.statusText}</span></div>
                    <div className="ir-row"><span className="k">Anchors</span><span className="v mono">{selected.inspector.anchors}</span></div>
                    <div className="ir-row"><span className="k">Migrated from</span><span className="v">{selected.inspector.migratedFrom}</span></div>
                    <div className="ir-row"><span className="k">Annotations</span><span className="v mono">{selected.inspector.annotations}</span></div>
                  </div>

                  <div className="ir-section">
                    <div className="label">History</div>
                    <div className="ir-mini-timeline">
                      {selected.history.map((h, i) => (
                        <div className={"mt" + (h.cur ? " cur" : "")} key={i} style={h.ghost ? { opacity: 0.5 } : null}>
                          <span className="dt" style={h.ghost ? { background: "transparent", border: "1px dashed var(--ink-4)" } : null} />
                          <span>{h.v} · {h.note}</span>
                          <span className="when">{h.when}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="ir-actions">
                    <button className="btn ghost sm" style={{ flex: 1 }}>Open diff</button>
                    <button className="btn sm" style={{ flex: 1 }}>Open chart →</button>
                  </div>
                </aside>
              </div>

              <div className="note-callout" style={{ marginTop: 22 }}>
                <div className="l">B · hybrid — hero + expanding tiles + inspector</div>
                Three reading modes layered: the hero score on top for the conductor's view, expanding tiles for at-a-glance detail per part, and a persistent inspector on the right that follows selection. <strong>Open chart →</strong> in the inspector takes you into the regular chart-reading view.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// B · NO conductor's score — wider parts, no score-lane tag, breathing room
// ============================================================
const REST_B_NOSCORE_PARTS = REST_B_PARTS.filter(p => p.kind !== "score");

function HfRestingBNoScore() {
  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar
            right={
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <button className="btn ghost sm">Share</button>
                <button className="btn sm">Add part</button>
              </div>
            }
          />
          <div className="hf-content">
            <div className="hf-inner wide">
              <ChartHead
                version="v3"
                versions={["v3", "v2", "v1"]}
                partsCount={3}
                whenText="parts only · chamber piece"
              />

              <div className="parts-tiles-head spaced">
                <h3 className="ps-title">Parts</h3>
                <span className="ps-meta">3 active · 2 changed since v2</span>
                <button className="ps-add" type="button">
                  <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6">
                    <path d="M8 3 L8 13 M3 8 L13 8" strokeLinecap="round" />
                  </svg>
                  <span>Add part</span>
                </button>
              </div>

              {/* Wider tiles — fewer per row, more room */}
              <div className="parts-tiles wide">
                {REST_B_NOSCORE_PARTS.map(p => (
                  <article className={"part-tile big" + (p.changed ? " changed" : " stable")} key={p.id}>
                    <header className="pt-head">
                      <span className="pt-icn"><InstrumentIcon slot={p.icon} size={22} /></span>
                      <span className="pt-name">{p.slot}</span>
                      <span className={"pt-status " + (p.changed ? "is-changed" : "is-stable")}>
                        {p.status}
                      </span>
                    </header>
                    <div className="pt-thumb tall">
                      <MiniScoreThumb kind="part" changed={p.changed} />
                    </div>
                    <div className="pt-info">
                      <div className="pt-info-row">
                        <span className="k">Migrated from</span>
                        <span className="v">{p.inspector.migratedFrom}</span>
                      </div>
                      <div className="pt-info-row">
                        <span className="k">Anchors</span>
                        <span className="v mono">{p.inspector.anchors}</span>
                      </div>
                    </div>
                    <footer className="pt-foot">
                      <span className="pt-file">{p.file}</span>
                      <Spark values={p.spark} />
                    </footer>
                  </article>
                ))}
              </div>

              {/* Quiet score CTA — bottom of view, not a banner */}
              <div className="quiet-add-score">
                <div className="qas-icon">
                  <InstrumentIcon slot="score" size={18} />
                </div>
                <div className="qas-text">
                  <strong>Add a conductor's score?</strong> <span className="muted">Parts will re-anchor automatically.</span>
                </div>
                <button className="btn ghost sm">Upload score</button>
              </div>

              <div className="note-callout" style={{ marginTop: 22 }}>
                <div className="l">B · no conductor's score — chamber edge case</div>
                Score lane removed entirely from the layout — no SCORE tag, no spotlight. Parts get more room (3-up max), each tile carries its own migration + anchor info. The "add a score" affordance lives quietly below the parts so directors who never want one aren't nagged.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- C · Score-led ----------

// ---------- C · Score-led ----------
function HfRestingC() {
  const parts = [
    { slot: "Score", icon: "score", file: "score_v3.pdf", status: "v3 · updated", changed: true, current: true },
    { slot: "Cello", icon: "cello", file: "cello_v1.pdf", status: "carried forward", changed: false },
    { slot: "Violin 1", icon: "violin", file: "violin1_v3.pdf", status: "v3 · 4 measures", changed: true },
    { slot: "Viola", icon: "viola", file: "viola_v3.pdf", status: "v3 · 1 measure", changed: true },
  ];

  return (
    <div className="hf">
      <div className="hf-shell">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar
            right={
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <button className="btn ghost sm">Share</button>
                <button className="btn sm">Add part</button>
              </div>
            }
          />
          <div className="hf-content">
            <div className="hf-inner">
              <ChartHead
                version="v3"
                versions={["v3", "v2", "v1"]}
                partsCount={4}
                whenText="pushed Tue · 2 parts changed since v2"
              />

              <div className="score-led">
                <div className="score-led-hero">
                  <div className="sl-bar">
                    <span className="l">Score · Conductor's view</span>
                    <span className="a">v3 ▾</span>
                    <span className="a">Open ↗</span>
                    <span className="pn">p. 1 / 18 · 4 staves</span>
                  </div>
                  <div className="sl-page">
                    <button className="sl-drop">
                      <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6">
                        <path d="M8 2 L8 11 M4 7 L8 11 L12 7" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M2 13 L14 13" strokeLinecap="round" />
                      </svg>
                      <span>drop PDFs anywhere</span>
                    </button>
                    <div className="sl-system">
                      {[0,1,2,3,4].map(i => <div className="sl-line" key={i} />)}
                    </div>
                    <div className="sl-system">
                      {[0,1,2,3,4].map(i => <div className="sl-line" key={i} />)}
                    </div>
                    <div className="sl-system">
                      {[0,1,2,3,4].map(i => <div className="sl-line" key={i} />)}
                    </div>
                    <div className="sl-pageno">— 1 —</div>
                  </div>
                  <div className="sl-drophint">
                    DROP A PDF ANYWHERE ON THIS PAGE TO ADD OR REPLACE A PART
                  </div>
                </div>

                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 4 }}>
                  <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--ink-3)" }}>
                    Parts · 4 active
                  </div>
                  <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-4)" }}>
                    click to open · ⌘↩ to push
                  </div>
                </div>

                <div className="parts-strip">
                  {parts.map((p, i) => (
                    <div className={"part-strip-item " + (p.changed ? "has-change " : "") + (p.current ? "cur" : "")} key={i}>
                      <div className="hbtn">
                        v3
                        {p.changed && <span style={{ width: 6, height: 6, borderRadius: 999, background: "var(--accent)" }} />}
                      </div>
                      <div className="top">
                        <span className="icn"><InstrumentIcon slot={p.icon} size={20} /></span>
                        <span className="name">{p.slot}</span>
                      </div>
                      <div className="meta">
                        <span style={{ color: p.changed ? "var(--accent)" : "var(--ink-3)" }}>{p.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="note-callout" style={{ marginTop: 22 }}>
                <div className="l">C · score-led</div>
                Score is the page. The whole reading surface is the drop target — the director drops a PDF "onto the music" rather than into a list. Parts strip below is a horizontal rhythm of slots; selecting one swaps the hero. The score's centrality matches how directors actually navigate.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- D · Inspector layout ----------
function HfRestingD() {
  const parts = [
    { slot: "Score", icon: "score", file: "lunar-noon-score_v3.pdf", status: "v3 · updated", changed: true, kind: "score" },
    { slot: "Cello", icon: "cello", file: "cello_v1.pdf", status: "carried forward" },
    { slot: "Violin 1", icon: "violin", file: "violin1_v3.pdf", status: "v3 · 4 measures", changed: true, selected: true },
    { slot: "Viola", icon: "viola", file: "viola_v3.pdf", status: "v3 · 1 measure", changed: true },
  ];

  return (
    <div className="hf">
      <div className="hf-shell-3col">
        <HfSidebar />
        <div className="hf-main">
          <HfTopBar
            right={
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <button className="btn ghost sm">Share</button>
                <button className="btn sm">Add part</button>
              </div>
            }
          />
          <div className="hf-content">
            <div className="hf-inner">
              <ChartHead
                version="v3"
                versions={["v3", "v2", "v1"]}
                partsCount={4}
                whenText="pushed Tue · 2 parts changed since v2"
              />

              <div className="compact-list">
                {parts.map((p, i) => (
                  <div className={"compact-row" + (p.selected ? " selected" : "")} key={i}>
                    <span className="icn"><InstrumentIcon slot={p.icon} size={20} /></span>
                    <span>
                      <div className="nm">{p.slot}{p.kind === "score" && <span style={{ marginLeft: 8, fontFamily: "var(--mono)", fontSize: 10, padding: "1px 6px", border: "1px solid var(--line)", borderRadius: 3, color: "var(--ink-3)", verticalAlign: "1px" }}>SCORE</span>}</div>
                      <div className="filename">{p.file}</div>
                    </span>
                    <span className="right">
                      <span style={{ fontFamily: "var(--mono)", fontSize: 11, color: p.changed ? "var(--accent)" : "var(--ink-3)" }}>
                        {p.status}
                      </span>
                      <HistoryButton versionsCount={3} badged={p.changed} />
                    </span>
                  </div>
                ))}
              </div>

              <div className="inspector-drop">
                <div className="big">Drop PDFs to add or replace parts</div>
                <div className="sml">⌘ U · or click to choose · 17 PDFs at once is fine</div>
              </div>

              <div className="note-callout" style={{ marginTop: 18 }}>
                <div className="l">D · inspector layout</div>
                Compact left list of parts; right rail is the Inspector. Selecting a part populates the rail with its history, migration source, and per-part actions. Drop zone is generous and lives in the main canvas. This is the densest direction — best when directors juggle many charts and want a Figma-style "select-and-edit" rhythm.
              </div>
            </div>
          </div>
        </div>

        {/* Right inspector rail */}
        <div className="inspector-rail">
          <div className="ir-head">
            <div className="icn"><InstrumentIcon slot="violin" size={22} /></div>
            <div>
              <div className="nm">Violin 1</div>
              <div className="sub">selected · v3</div>
            </div>
          </div>

          <div className="ir-section">
            <div className="label">File</div>
            <div className="ir-row"><span className="k">Filename</span><span className="v mono">violin1_v3.pdf</span></div>
            <div className="ir-row"><span className="k">Size</span><span className="v mono">1.24 MB</span></div>
            <div className="ir-row"><span className="k">Pages</span><span className="v mono">3</span></div>
            <div className="ir-row"><span className="k">Slot</span><span className="v">Violin 1</span></div>
          </div>

          <div className="ir-section">
            <div className="label">This version</div>
            <div className="ir-row"><span className="k">Status</span><span className="v" style={{ color: "var(--accent)" }}>4 measures changed</span></div>
            <div className="ir-row"><span className="k">Anchors</span><span className="v mono">m.17 · 18 · 34</span></div>
            <div className="ir-row"><span className="k">Migrated from</span><span className="v">Violin 1 · v2</span></div>
            <div className="ir-row"><span className="k">Annotations</span><span className="v mono">7 re-anchored</span></div>
          </div>

          <div className="ir-section">
            <div className="label">History</div>
            <div className="ir-mini-timeline">
              <div className="mt cur"><span className="dt" /><span>v3 · 4 measures</span><span className="when">Tue</span></div>
              <div className="mt"><span className="dt" /><span>v2 · created</span><span className="when">Apr 14</span></div>
              <div className="mt" style={{ opacity: 0.5 }}><span className="dt" style={{ background: "transparent", border: "1px dashed var(--ink-4)" }} /><span>v1 · n/a</span><span className="when">—</span></div>
            </div>
          </div>

          <div style={{ display: "flex", gap: 6, marginTop: "auto" }}>
            <button className="btn ghost sm" style={{ flex: 1 }}>Open diff</button>
            <button className="btn sm" style={{ flex: 1 }}>Replace ↑</button>
          </div>
        </div>
      </div>
    </div>
  );
}

window.HfRestingB = HfRestingB;


window.HfRestingB = HfRestingB;
window.HfRestingBHybrid = HfRestingBHybrid;
window.HfRestingBNoScore = HfRestingBNoScore;
window.HfRestingC = HfRestingC;
window.HfRestingD = HfRestingD;
