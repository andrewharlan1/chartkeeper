// Storyboard B — New version (case #3) + Alternative direction (upload tray)
// Two short flows demonstrating the harder-to-show cases.

// ----- Case #3: New version of existing chart -----

function StoryV2({ frame = 0 }) {
  // v1 has all 8 parts assigned. Director drops a single revised cello/alto-sax PDF.
  // For our 8-piece big band roster, "revised" target = Alto Sax 1.
  const v1Parts = [
    { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score.pdf" },
    { slot: "Trumpet 1", icon: "trumpet", file: "tpt1.pdf" },
    { slot: "Trumpet 2", icon: "trumpet", file: "tpt2.pdf" },
    { slot: "Alto Sax 1", icon: "sax", file: "as1.pdf" },
    { slot: "Tenor Sax", icon: "sax", file: "ts.pdf" },
    { slot: "Piano", icon: "piano", file: "pno.pdf" },
    { slot: "Bass", icon: "bass", file: "bs.pdf" },
    { slot: "Drums", icon: "drums", file: "drm.pdf" },
  ];

  if (frame === 0) {
    return (
      <FrameShell
        num="v2 · 01 / 04"
        caption={<><b>Resting on v1.</b> Roster is fully populated. Director drags <span className="mono">alto1_REV.pdf</span> from Finder.</>}
      >
        <BaseChart parts={v1Parts} version="v1" versions={["v1"]} />
        <DragStack count={1} x={520} y={300} label="PDF" />
        <Cursor x={560} y={314} />
        <div className="scribble" style={{ left: 590, top: 360, transform: "rotate(-3deg)" }}>
          single revised<br/>chart →
        </div>
      </FrameShell>
    );
  }

  if (frame === 1) {
    // System detects same-instrument-same-chart → proposes v2 seeded from v1 with this part replaced.
    return (
      <FrameShell
        num="v2 · 02 / 04"
        caption={<><b>Recognized.</b> Same chart, same instrument as an existing slot → proposed action is "replace Alto Sax 1, bump to v2." Slot picking is skipped — director just confirms the version intent.</>}
      >
        <BaseChart
          parts={v1Parts}
          version="v1"
          versions={["v1"]}
          slot={
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <Banner kind="">
                <span className="mono" style={{ fontSize: 11, letterSpacing: "0.05em" }}>1 FILE · MATCHED EXISTING SLOT</span>
                <span className="dim mono" style={{ fontSize: 11, marginLeft: "auto" }}>OMR confirms</span>
              </Banner>
              <div style={{ border: "1px solid var(--line-2)", background: "var(--paper)", padding: 14 }}>
                <div className="mono dim" style={{ fontSize: 11, marginBottom: 10 }}>SCORVA THINKS</div>
                <div style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 14 }}>
                  <span className="file-card" style={{ padding: "8px 12px" }}>
                    <span style={{ color: "var(--ink-2)" }}><InstrumentIcon slot="sax" size={20} /></span>
                    <span className="name">alto1_REV.pdf</span>
                  </span>
                  <span className="mono dim" style={{ fontSize: 18 }}>→</span>
                  <span style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", border: "1px solid var(--line-2)" }}>
                    <InstrumentIcon slot="sax" size={20} />
                    <span style={{ fontWeight: 500 }}>Alto Sax 1</span>
                    <span className="diff-pill">replaces</span>
                  </span>
                </div>
                <div style={{ marginTop: 14, display: "flex", gap: 10, alignItems: "center" }}>
                  <label className="mono" style={{ fontSize: 12, display: "flex", gap: 6, alignItems: "center" }}>
                    <input type="radio" defaultChecked /> add as <b>v2</b>, seed other 7 parts forward from v1
                  </label>
                </div>
                <div style={{ marginTop: 6, display: "flex", gap: 10, alignItems: "center" }}>
                  <label className="mono dim" style={{ fontSize: 12, display: "flex", gap: 6, alignItems: "center" }}>
                    <input type="radio" /> replace Alto Sax 1 in v1 (no version bump)
                  </label>
                </div>
                <div style={{ marginTop: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span className="chip guess">change slot</span>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button className="btn ghost">Cancel</button>
                    <button className="btn">Push v2</button>
                  </div>
                </div>
              </div>
            </div>
          }
        />
      </FrameShell>
    );
  }

  if (frame === 2) {
    // v2 created — parts list shows seeded parts + the changed one
    const v2Parts = [
      { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score.pdf", _seeded: true },
      { slot: "Trumpet 1", icon: "trumpet", file: "tpt1.pdf", _seeded: true },
      { slot: "Trumpet 2", icon: "trumpet", file: "tpt2.pdf", _seeded: true },
      { slot: "Alto Sax 1", icon: "sax", file: "alto1_REV.pdf", diff: "v2 · changed" },
      { slot: "Tenor Sax", icon: "sax", file: "ts.pdf", _seeded: true },
      { slot: "Piano", icon: "piano", file: "pno.pdf", _seeded: true },
      { slot: "Bass", icon: "bass", file: "bs.pdf", _seeded: true },
      { slot: "Drums", icon: "drums", file: "drm.pdf", _seeded: true },
    ];
    return (
      <FrameShell
        num="v2 · 03 / 04"
        caption={<><b>v2 exists.</b> One row marked changed; the other seven seeded forward unchanged. Director never had to re-pick a slot.</>}
      >
        <BaseChart parts={v2Parts} version="v2" versions={["v2", "v1"]} />
      </FrameShell>
    );
  }

  if (frame === 3) {
    return (
      <FrameShell
        num="v2 · 04 / 04"
        caption={<><b>What if Scorva guessed wrong?</b> "Change slot" on the proposal opens the same instrument popover as the bulk flow. Same gesture, same icons, same vocabulary — never two ways to do the same thing.</>}
      >
        <BaseChart
          parts={v1Parts}
          version="v1"
          versions={["v1"]}
          slot={
            <div style={{ position: "relative", border: "1px solid var(--line-2)", background: "var(--paper)", padding: 14 }}>
              <div className="mono dim" style={{ fontSize: 11, marginBottom: 10 }}>SCORVA THINKS · CHANGING</div>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span className="file-card" style={{ padding: "8px 12px" }}>
                  <InstrumentIcon slot="sax" size={20} />
                  <span className="name">alto1_REV.pdf</span>
                </span>
                <span className="mono dim" style={{ fontSize: 18 }}>→</span>
                <span style={{ position: "relative" }}>
                  <span style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", border: "1.5px solid var(--accent)", background: "var(--accent-soft)" }}>
                    <InstrumentIcon slot="sax" size={20} />
                    <span style={{ fontWeight: 500 }}>pick slot…</span>
                  </span>
                  <div className="popover" style={{ left: 0, top: 44 }}>
                    <div className="head">Route to</div>
                    {window.SCORVA_ROSTER.filter((r) => r.role !== "score").map((r) => (
                      <div className={"opt" + (r.slot === "Alto Sax 1" ? " cur" : "")} key={r.slot}>
                        <InstrumentIcon slot={r.icon} size={18} />
                        <span>{r.slot}</span>
                        <span className="dim mono" style={{ marginLeft: "auto", fontSize: 10 }}>
                          {r.slot === "Alto Sax 1" ? "current" : (r.slot === "Tenor Sax" ? "empty? no" : "")}
                        </span>
                      </div>
                    ))}
                  </div>
                </span>
              </div>
            </div>
          }
        />
      </FrameShell>
    );
  }

  return null;
}

// ----- Alternative direction: ambient upload tray -----

function StoryTray({ frame = 0 }) {
  const v1Parts = [
    { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score.pdf" },
    { slot: "Trumpet 1", icon: "trumpet", file: "tpt1.pdf" },
    { slot: "Trumpet 2", icon: "trumpet", file: "tpt2.pdf" },
    { slot: "Alto Sax 1", icon: "sax", file: "as1.pdf" },
    { slot: "Tenor Sax", icon: "sax", file: "ts.pdf" },
    { slot: "Piano", icon: "piano", file: "pno.pdf" },
    { slot: "Bass", icon: "bass", file: "bs.pdf" },
    { slot: "Drums", icon: "drums", file: "drm.pdf" },
  ];

  // Tray rows for 9 incoming files
  const trayRows = [
    { file: "Tpt 1.pdf", slot: "Trumpet 1", icon: "trumpet" },
    { file: "Trumpet_2_FINAL.pdf", slot: "Trumpet 2", icon: "trumpet" },
    { file: "AS1.pdf", slot: "Alto Sax 1", icon: "sax" },
    { file: "tenor sax v3.pdf", slot: "Tenor Sax", icon: "sax" },
    { file: "piano-pt.pdf", slot: "Piano", icon: "piano" },
    { file: "bass.pdf", slot: "Bass", icon: "bass" },
    { file: "drums chart.pdf", slot: "Drums", icon: "drums" },
    { file: "Untitled-1.pdf", slot: null, icon: "unknown", unsure: true },
    { file: "lunar-noon SCORE.pdf", slot: "Score", icon: "score" },
  ];

  // Three frames: ambient resting, mid-routing, expanded
  if (frame === 0) {
    return (
      <FrameShell
        num="alt · 01 / 03"
        caption={<><b>Ambient tray.</b> A persistent corner well always accepts drops. Doesn't take over the page. Good for directors who upload as they work — chart, listen, drop, chart, drop.</>}
      >
        <div style={{ position: "relative", height: "100%" }}>
          <BaseChart parts={v1Parts} />
          <div className="tray">
            <div className="head">
              <span>Upload tray</span>
              <span className="dim">empty</span>
            </div>
            <div className="body" style={{ minHeight: 80, color: "var(--ink-3)", fontSize: 12, fontFamily: "Geist Mono, ui-monospace, monospace", display: "flex", alignItems: "center", justifyContent: "center" }}>
              drop PDFs anywhere
            </div>
          </div>
        </div>
      </FrameShell>
    );
  }

  if (frame === 1) {
    return (
      <FrameShell
        num="alt · 02 / 03"
        caption={<><b>Mid-flow.</b> 9 files routing in the corner. Director can keep working — fix routing without leaving the page. Unsure rows yellow; one click resolves them.</>}
      >
        <div style={{ position: "relative", height: "100%" }}>
          <BaseChart parts={v1Parts} />
          <div className="tray" style={{ width: 360 }}>
            <div className="head">
              <span>Upload tray · 9 files</span>
              <span style={{ color: "var(--warn)" }}>1 needs review</span>
            </div>
            <div className="body">
              {trayRows.map((r, i) => (
                <div className="item" key={i} style={r.unsure ? { background: "var(--warn-soft)" } : {}}>
                  <div style={{ minWidth: 0 }}>
                    <div className="fn" title={r.file}>{r.file}</div>
                  </div>
                  <div className="target">
                    {r.unsure ? (
                      <span style={{ color: "var(--warn)" }}>pick slot…</span>
                    ) : (
                      <>
                        <InstrumentIcon slot={r.icon} size={14} />
                        <span>{r.slot}</span>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <div className="foot">
              <button className="btn ghost sm">Clear</button>
              <button className="btn sm" disabled>Add 9 to v1</button>
            </div>
          </div>
        </div>
      </FrameShell>
    );
  }

  if (frame === 2) {
    return (
      <FrameShell
        num="alt · 03 / 03"
        caption={<><b>Trade-off.</b> Tray keeps the page calm but hides the routing review at small size. Probably wants an "expand" affordance that swaps to the inline review. Worth comparing against Storyboard A.</>}
      >
        <div style={{ position: "relative", height: "100%" }}>
          <BaseChart parts={v1Parts} />
          <div className="tray" style={{ width: 540, bottom: 18, right: 18 }}>
            <div className="head">
              <span>Upload tray · expanded</span>
              <span className="dim">9 files · 1 needs review</span>
            </div>
            <div className="body" style={{ padding: 0, maxHeight: 320 }}>
              <ReviewTable rows={trayRows.map((r) => r.unsure ? { ...r, unsure: true } : r)} showHead={false} />
            </div>
            <div className="foot">
              <button className="btn ghost sm">Cancel</button>
              <button className="btn sm" disabled>Add 9 to v1</button>
            </div>
          </div>
          <div className="scribble" style={{ left: 60, top: 240, transform: "rotate(-3deg)", color: "var(--ink-3)" }}>
            risk: two surfaces<br/>(small tray + expanded)<br/>= cognitive load
          </div>
        </div>
      </FrameShell>
    );
  }

  return null;
}

window.StoryV2 = StoryV2;
window.StoryTray = StoryTray;
