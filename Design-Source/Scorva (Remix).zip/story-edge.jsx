// Edge-case mini frames — case #1 (fresh chart, single PDF) and case #4 (score)
// Plus a small "wrong slot, after the fact" recovery frame.

function StoryEdge({ which = "fresh" }) {
  if (which === "fresh") {
    // Case #1 — one PDF, fresh chart with empty roster (just slots, no parts yet).
    return (
      <FrameShell
        num="case #1 · single drop"
        caption={<><b>Fresh chart, one PDF.</b> Empty parts list. Drop one cello PDF → recognized → lands directly. No review screen for an obvious single-file case.</>}
      >
        <div style={{ position: "relative", height: "100%" }}>
          <BaseChart
            parts={[]}
            slot={
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <Banner kind="ok">
                  <span className="mono" style={{ fontSize: 11, letterSpacing: "0.05em" }}>1 FILE · ROUTED · cello.pdf → BASS slot</span>
                  <span className="dim mono" style={{ fontSize: 11, marginLeft: "auto" }}>↶ undo</span>
                </Banner>
                <SlotGrid
                  assigned={{ Bass: "cello.pdf" }}
                  target="Bass"
                />
                <span className="mono dim" style={{ fontSize: 11 }}>
                  No review needed for one obvious match. If wrong, click the slot to re-pick.
                </span>
              </div>
            }
          />
        </div>
      </FrameShell>
    );
  }

  if (which === "score") {
    // Case #4 — score handling. Per answer: toggle on each row in routing review.
    const rows = [
      { file: "lunar-noon SCORE.pdf", slot: "Score", icon: "score", kind: "score", conf: 3 },
      { file: "Tpt 1.pdf", slot: "Trumpet 1", icon: "trumpet", conf: 3 },
      { file: "Untitled-2.pdf", slot: "Piano", icon: "piano", conf: 2 },
    ];
    return (
      <FrameShell
        num="case #4 · the score"
        caption={<><b>Score, not a part.</b> The "score" checkbox lives in the same review row, pre-checked when Scorva detects a full-score layout. Per-row, doesn't bloat normal uploads.</>}
      >
        <BaseChart
          parts={[]}
          slot={
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <Banner kind="">
                <span className="mono" style={{ fontSize: 11, letterSpacing: "0.05em" }}>3 FILES · 1 SCORE · 2 PARTS</span>
              </Banner>
              <ReviewTable rows={rows} />
              <div className="mono dim" style={{ fontSize: 11 }}>
                "score" toggles once per row — not a separate flow, not a global mode.
              </div>
            </div>
          }
        />
      </FrameShell>
    );
  }

  if (which === "wrong") {
    // Case #5 — wrong slot, after the fact. Showing post-landing fix.
    const landed = [
      { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score.pdf" },
      { slot: "Trumpet 1", icon: "trumpet", file: "tpt1.pdf" },
      { slot: "Alto Sax 1", icon: "sax", file: "Untitled-1.pdf" },
      { slot: "Tenor Sax", icon: "sax", file: "ts.pdf" },
    ];
    return (
      <FrameShell
        num="case #5 · re-pick after"
        caption={<><b>Wrong slot, after the fact.</b> The slot column is the affordance. Click it any time — same popover that appears during routing.</>}
      >
        <div style={{ position: "relative", height: "100%" }}>
          <BaseChart parts={landed} />
          <div className="popover" style={{ left: 320, top: 250 }}>
            <div className="head">Untitled-1.pdf — re-pick</div>
            {window.SCORVA_ROSTER.filter((r) => r.role !== "score").slice(0, 6).map((r) => (
              <div className={"opt" + (r.slot === "Alto Sax 1" ? " cur" : "")} key={r.slot}>
                <InstrumentIcon slot={r.icon} size={18} />
                <span>{r.slot}</span>
              </div>
            ))}
          </div>
          <div className="scribble" style={{ left: 380, top: 200, transform: "rotate(-2deg)" }}>
            same gesture<br/>everywhere ✓
          </div>
        </div>
      </FrameShell>
    );
  }

  return null;
}

window.StoryEdge = StoryEdge;
