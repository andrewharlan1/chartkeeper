// New shared primitives for the expanded brief.
// Roster: chamber set per scenarios (cello, violin 1, viola, +score lane).

const CHAMBER = [
  { slot: "Score", icon: "score", role: "score" },
  { slot: "Cello", icon: "cello" },
  { slot: "Violin 1", icon: "violin" },
  { slot: "Viola", icon: "viola" },
];

window.SCORVA_CHAMBER = CHAMBER;

// ---- Chrome (extends earlier AppBar/Sidebar styling, smaller) ----

function ChamberSidebar() {
  return (
    <div className="sidebar">
      <div className="group">Workspace</div>
      <div className="item">Helen's Workspace</div>
      <div className="group">Ensembles</div>
      <div className="item active">String Trio + Score</div>
      <div className="item sub">› Charts</div>
      <div className="item sub">› Roster</div>
      <div className="group">Charts</div>
      <div className="item sub" style={{ color: "var(--ink)" }}>· Lunar Noon</div>
      <div className="item sub">· Equinox</div>
      <div className="item sub">· Open Air</div>
    </div>
  );
}

// ---- Parts list with HISTORY affordance per row ----
// Each row: icon · slot · file · history button (badged when there's a recent change)

function PartsListV2({ parts, version = "v3", onOpenHistory, hideRemoved = false, draggable = true }) {
  const visible = hideRemoved ? parts.filter(p => p.statusKind !== "removed") : parts;
  const [dragIdx, setDragIdx] = React.useState(-1);
  const [order, setOrder] = React.useState(null);
  const rows = order ? order.map(i => visible[i]).filter(Boolean) : visible;

  // Reset order if parts list changes shape
  React.useEffect(() => { setOrder(null); }, [visible.length]);

  const handleDragStart = (i) => setDragIdx(i);
  const handleDragOver = (e, i) => {
    e.preventDefault();
    if (dragIdx === -1 || dragIdx === i) return;
    const cur = order || rows.map((_, k) => k);
    const next = [...cur];
    const [moved] = next.splice(dragIdx, 1);
    next.splice(i, 0, moved);
    setOrder(next);
    setDragIdx(i);
  };
  const handleDragEnd = () => setDragIdx(-1);

  return (
    <div className="parts">
      <div className="row head v2 with-drag">
        <span />
        <span />
        <span>Slot</span>
        <span>File</span>
        <span>Status</span>
        <span style={{ textAlign: "right" }}>History</span>
      </div>
      {rows.map((p, i) => (
        <div
          className={"row v2 with-drag" + (dragIdx === i ? " dragging" : "") + (p.statusKind === "removed" ? " removed" : "")}
          key={p.slot}
          draggable={draggable}
          onDragStart={() => handleDragStart(i)}
          onDragOver={(e) => handleDragOver(e, i)}
          onDragEnd={handleDragEnd}
        >
          <span className="drag-handle" title="Drag to reorder">
            <svg width="10" height="14" viewBox="0 0 10 14" fill="currentColor"><circle cx="3" cy="3" r="1"/><circle cx="7" cy="3" r="1"/><circle cx="3" cy="7" r="1"/><circle cx="7" cy="7" r="1"/><circle cx="3" cy="11" r="1"/><circle cx="7" cy="11" r="1"/></svg>
          </span>
          <span style={{ color: "var(--ink-2)" }}><InstrumentIcon slot={p.icon || p.slot} size={20} /></span>
          <span className="slot">
            <span style={{ fontWeight: 500 }}>{p.slot}</span>
            {p.kind === "score" && <span className="chip mono" style={{ fontSize: 10 }}>score</span>}
          </span>
          <span className="filename">{p.file || <span className="dim">—</span>}</span>
          <span className="mono" style={{ fontSize: 11 }}>
            {p.statusLabel ? (
              <span className={"status-pill " + (p.statusKind || "")}>
                {p.statusLabel}
              </span>
            ) : (
              <span className="dim">unchanged</span>
            )}
          </span>
          <span style={{ textAlign: "right", display: "flex", gap: 6, alignItems: "center", justifyContent: "flex-end" }}>
            <span className="dim mono" style={{ fontSize: 11 }}>v{p.versionsCount || 1}</span>
            <button
              className={"history-btn" + (p.historyBadge ? " badged" : "")}
              onClick={() => onOpenHistory && onOpenHistory(p.slot)}
              title="History"
            >
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
                <circle cx="8" cy="8" r="6" />
                <path d="M8 4 L8 8 L11 9.5" strokeLinecap="round" />
              </svg>
              {p.historyBadge && <span className="badge-dot" />}
            </button>
          </span>
        </div>
      ))}
    </div>
  );
}

// ---- Chart header w/ auto-version ----

function ChartHeaderV2({ version = "v3", versions = ["v3", "v2", "v1"], optName = "" }) {
  return (
    <div>
      <div className="h-eyebrow">Chart</div>
      <h1 className="title">Lunar Noon</h1>
      <div className="version-row" style={{ marginTop: 10 }}>
        <select className="version-pick" defaultValue={version}>
          {versions.map((v) => <option key={v}>{v}</option>)}
        </select>
        {optName && <span className="version-name">{optName}</span>}
        <span className="dim mono">· auto-versioned · {versions.length} versions</span>
      </div>
    </div>
  );
}

// ---- Tray (drop result) — list of files w/ slot guess + per-row migration ----

function UploadTray({ files, onMigrationOpen, openIndex = -1, version = "v2", showMigration = true, embedded = false }) {
  return (
    <div className={"tray-inline" + (embedded ? " embedded" : "")}>
      <div className="tray-head">
        <span className="mono" style={{ fontSize: 11, letterSpacing: "0.05em" }}>
          UPLOAD · {files.length} FILE{files.length !== 1 ? "S" : ""} · WILL CREATE {version}
        </span>
        <span className="dim mono" style={{ fontSize: 11, marginLeft: "auto" }}>unchanged parts carry forward implicitly</span>
      </div>
      <div className="tray-rows">
        {files.map((f, i) => (
          <div className={"tray-row" + (f.unsure ? " unsure" : "")} key={i}>
            <div className="t-icon">
              <InstrumentIcon slot={f.unsure ? "unknown" : (f.icon || f.slot)} size={20} />
            </div>
            <div className="t-file">
              <div className="t-fn mono">{f.file}</div>
              <div className="t-meta mono dim">{f.size || "—"}</div>
            </div>
            <div className="t-arrow mono">→</div>
            <div className="t-target">
              {f.unsure ? (
                <span className="chip unsure">pick slot…</span>
              ) : (
                <span className="t-slot">
                  <span style={{ fontWeight: 500 }}>{f.slot}</span>
                  <span className="chip guess">change</span>
                </span>
              )}
            </div>
            {showMigration && (
              <div className="t-mig">
                <button
                  className={"mig-btn" + (openIndex === i ? " open" : "")}
                  onClick={() => onMigrationOpen && onMigrationOpen(i)}
                >
                  <span className="dim mono" style={{ fontSize: 10, marginRight: 6 }}>migrate from</span>
                  <span style={{ fontWeight: 500 }}>{f.migration || "—"}</span>
                  <span className="dim mono" style={{ marginLeft: 6 }}>▾</span>
                </button>
              </div>
            )}
            <div className="t-kind">
              <label className="mono" style={{ fontSize: 11, display: "flex", gap: 4, alignItems: "center" }}>
                <input type="checkbox" defaultChecked={f.kind === "score"} /> score
              </label>
            </div>
          </div>
        ))}
      </div>
      <div className="tray-foot">
        <input
          className="version-name-input"
          placeholder="(optional) version name — e.g. recording session draft"
        />
        <span style={{ flex: 1 }} />
        <button className="btn ghost">Cancel</button>
        <button className="btn">Publish v2</button>
      </div>
    </div>
  );
}

// ---- Migration source picker (popover) ----

function MigrationPicker({ x = 460, y = 220, partLabel = "Violin 1", currentSlot = "Violin 1", chosen = "Cello · v1" }) {
  return (
    <div className="popover migration-pop" style={{ left: x, top: y, width: 320 }}>
      <div className="head">Migrate annotations into {partLabel} from</div>
      <div className="opt-group mono dim" style={{ padding: "4px 8px", fontSize: 10, letterSpacing: "0.08em" }}>
        SAME PART · PREVIOUS VERSIONS
      </div>
      <div className="opt"><InstrumentIcon slot="violin" size={16} /><span>Violin 1 · v1</span> <span className="dim mono" style={{ marginLeft: "auto", fontSize: 10 }}>didn't exist</span></div>
      <div className="opt-group mono dim" style={{ padding: "8px 8px 4px", fontSize: 10, letterSpacing: "0.08em" }}>
        SIBLING PART · ANY VERSION
      </div>
      <div className={"opt" + (chosen === "Cello · v1" ? " cur" : "")}>
        <InstrumentIcon slot="cello" size={16} /><span>Cello · v1</span>
        <span className="dim mono" style={{ marginLeft: "auto", fontSize: 10 }}>3 annotations</span>
      </div>
      <div className="opt"><InstrumentIcon slot="viola" size={16} /><span>Viola · v1</span> <span className="dim mono" style={{ marginLeft: "auto", fontSize: 10 }}>didn't exist</span></div>
      <div className="opt-group mono dim" style={{ padding: "8px 8px 4px", fontSize: 10, letterSpacing: "0.08em" }}>
        OR
      </div>
      <div className="opt"><span style={{ width: 16, display: "inline-block" }} /><span className="dim">No migration — clean part</span></div>
      <div style={{ borderTop: "1px solid var(--line-2)", marginTop: 6, padding: "8px 10px", fontSize: 11 }} className="mono dim">
        default: previous version of this part if it exists
      </div>
    </div>
  );
}

window.ChamberSidebar = ChamberSidebar;
window.PartsListV2 = PartsListV2;
window.ChartHeaderV2 = ChartHeaderV2;
window.UploadTray = UploadTray;
window.MigrationPicker = MigrationPicker;
