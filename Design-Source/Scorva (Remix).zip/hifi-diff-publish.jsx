/* global React, InstrumentIcon */
// ============================================================
// Scorva HI-FI: Diff log (PR-style) + Publish confirm (Pitch-style)
// ============================================================

function HfDiffLog({ file = "violin1.pdf", changedMeasures = [17, 18, 34], showInScore = true }) {
  const rows = [
    { m: "m.16", sigil: "", text: "unchanged", kind: "" },
    { m: "m.17", sigil: "−", text: <>E<sub>♭</sub> quarter note · beat 3</>, kind: "rem" },
    { m: "m.17", sigil: "+", text: "D quarter note · beat 3", kind: "add" },
    { m: "m.18", sigil: "~", text: "accent added · beat 1", kind: "mod" },
    { m: "m.19", sigil: "", text: "unchanged", kind: "" },
    { m: "", sigil: "", text: "… 14 unchanged measures collapsed ·", kind: "collapse", expandable: true },
    { m: "m.34", sigil: "~", text: "articulation: legato → tenuto", kind: "mod" },
  ];
  return (
    <div className="diff-card">
      <div className="head">
        <div className="title">{file}</div>
        <div className="summary">· <b>{changedMeasures.length} measures changed</b></div>
        <div className="anchors">
          {changedMeasures.map((m) => (
            <span className="a" key={m}>m.{m}</span>
          ))}
        </div>
      </div>
      <div className="body">
        {rows.map((r, i) => {
          if (r.kind === "collapse") {
            return (
              <div className="diff-row collapse" key={i}>
                {r.text} <span style={{ color: "var(--accent)", marginLeft: 4 }}>show all ›</span>
              </div>
            );
          }
          return (
            <div className={"diff-row " + r.kind} key={i}>
              <span className="m">{r.m}</span>
              <span className="sigil">{r.sigil}</span>
              <span>{r.text}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
// Publish confirmation (Pitch-style centered modal feel)
// ============================================================
function HfPublishConfirm() {
  return (
    <div className="publish-shell">
      <div className="publish-card">
        <div className="check">
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M7 14 L12 19 L21 9" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <h2>v2 is live</h2>
        <div className="summary">
          Pushed to <b>4 players</b>. Migration banners appear on first open.
        </div>

        <div className="breakdown">
          <div className="stat">
            <div className="num">+2</div>
            <div className="lab">parts added</div>
          </div>
          <div className="stat">
            <div className="num">1</div>
            <div className="lab">carried forward</div>
          </div>
          <div className="stat">
            <div className="num">6</div>
            <div className="lab">annotations seeded</div>
          </div>
        </div>

        <div className="actions">
          <button className="btn ghost">Back to chart</button>
          <button className="btn primary">View diff log →</button>
        </div>

        <div style={{
          marginTop: 18,
          fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-4)",
          letterSpacing: "0.04em",
        }}>
          undo within 60s · ⌘ Z
        </div>
      </div>
    </div>
  );
}

window.HfDiffLog = HfDiffLog;
window.HfPublishConfirm = HfPublishConfirm;
