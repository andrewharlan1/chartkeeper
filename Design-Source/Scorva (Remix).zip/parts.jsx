// Shared mock data + chart-page primitive components used across all frames.
// Geist + Geist Mono via Google Fonts; Caveat for handwritten captions.

const ROSTER = [
  { slot: "Score", icon: "score", role: "score" },
  { slot: "Trumpet 1", icon: "trumpet" },
  { slot: "Trumpet 2", icon: "trumpet" },
  { slot: "Alto Sax 1", icon: "sax" },
  { slot: "Tenor Sax", icon: "sax" },
  { slot: "Piano", icon: "piano" },
  { slot: "Bass", icon: "bass" },
  { slot: "Drums", icon: "drums" },
];

window.SCORVA_ROSTER = ROSTER;

// ---------- Chart page chrome ----------

function AppBar({ chart = "Lunar Noon", ensemble = "Tuesday Night Big Band", role = "director", otherEnsembles = [] }) {
  const [open, setOpen] = React.useState(false);
  return (
    <div className="app-bar">
      <div className="mono" style={{ letterSpacing: "0.02em", fontWeight: 600 }}>scorva</div>
      <div className="crumbs">
        <span>Helen's Workspace</span>
        <span>/</span>
        <span
          className="ensemble-switch"
          onClick={() => setOpen(o => !o)}
          style={{ position: "relative", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 }}
        >
          {ensemble}
          <span className="dim mono" style={{ fontSize: 10 }}>▾</span>
          {open && (
            <div className="popover" style={{ left: 0, top: 24, minWidth: 260, zIndex: 200 }}>
              <div className="head">Ensembles · your role varies</div>
              <div className="opt cur">
                <span style={{ fontWeight: 500 }}>{ensemble}</span>
                <span className="chip mono" style={{ marginLeft: "auto", fontSize: 10 }}>{role}</span>
              </div>
              {otherEnsembles.map((e) => (
                <div className="opt" key={e.name}>
                  <span>{e.name}</span>
                  <span className="chip mono" style={{ marginLeft: "auto", fontSize: 10, color: "var(--ink-3)" }}>{e.role}</span>
                </div>
              ))}
            </div>
          )}
        </span>
        <span>/</span>
        <b>{chart}</b>
      </div>
      <div className="spacer" />
      <span className="pill mono" title="Your role in this ensemble">{role}</span>
      <div style={{ width: 24, height: 24, borderRadius: 999, background: "var(--paper-2)", border: "1px solid var(--line-2)" }} />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="sidebar">
      <div className="group">Workspace</div>
      <div className="item">Helen's Workspace</div>
      <div className="group">Ensembles</div>
      <div className="item active">Tuesday Night Big Band</div>
      <div className="item sub">› Charts</div>
      <div className="item sub">› Roster</div>
      <div className="item">Saturday Quartet</div>
      <div className="item">Studio Sessions</div>
    </div>
  );
}

function ChartHeader({ version = "v1", versions = ["v1"], onPick }) {
  return (
    <div>
      <div className="h-eyebrow">Chart</div>
      <h1 className="title">Lunar Noon</h1>
      <div className="version-row" style={{ marginTop: 10 }}>
        <span className="mono">version</span>
        <select className="version-pick" value={version} onChange={(e) => onPick && onPick(e.target.value)}>
          {versions.map((v) => <option key={v}>{v}</option>)}
        </select>
        <span className="dim mono">· uploaded by Helen · Apr 18</span>
      </div>
    </div>
  );
}

// ---------- Parts list (table) ----------

function PartsList({ parts, emptyHint = "No parts yet. Drop PDFs to start." }) {
  if (!parts || parts.length === 0) {
    return (
      <div className="parts">
        <div className="row head">
          <span />
          <span>Slot</span>
          <span>Kind</span>
          <span>File</span>
          <span />
        </div>
        <div style={{ padding: "28px 14px", color: "var(--ink-3)", fontSize: 13, textAlign: "center", fontFamily: "Geist Mono, ui-monospace, monospace" }}>
          {emptyHint}
        </div>
      </div>
    );
  }
  return (
    <div className="parts">
      <div className="row head">
        <span />
        <span>Slot</span>
        <span>Kind</span>
        <span>File</span>
        <span />
      </div>
      {parts.map((p, i) => (
        <div className="row" key={i}>
          <span style={{ color: "var(--ink-2)" }}><InstrumentIcon slot={p.icon || p.slot} size={20} /></span>
          <span className="slot">
            <span style={{ fontWeight: 500 }}>{p.slot}</span>
            {p.diff && <span className="diff-pill">{p.diff}</span>}
          </span>
          <span className="mono dim">{p.kind || "part"}</span>
          <span className="filename">{p.file}</span>
          <span className="dim mono" style={{ textAlign: "right" }}>···</span>
        </div>
      ))}
    </div>
  );
}

// ---------- Drop zone (resting / active) ----------

function DropZone({ active = false, full = false, label }) {
  if (full) {
    return (
      <div className="drop full">
        <div style={{ fontSize: 28, fontWeight: 500, color: "var(--accent)" }}>Drop PDFs to add to Lunar Noon</div>
        <div className="mono" style={{ color: "var(--ink-3)", marginTop: 6 }}>
          v1 · 8 slots in roster · drop one or many
        </div>
      </div>
    );
  }
  return (
    <div className={"drop" + (active ? " active" : "")}>
      <span className="mono" style={{ fontSize: 18, marginRight: 4 }}>+</span>
      <span><strong>Drop PDFs here</strong> <span className="dim">or click to browse</span></span>
    </div>
  );
}

// ---------- Slot grid (used for fresh chart / score targeting) ----------

function SlotGrid({ assigned = {}, target = null, roster = ROSTER }) {
  return (
    <div className="slot-grid">
      {roster.map((r) => {
        const isTarget = target === r.slot;
        const isAssigned = !!assigned[r.slot];
        let cls = "slot-card";
        if (isTarget) cls += " target";
        else if (isAssigned) cls += " assigned";
        else cls += " empty";
        return (
          <div className={cls} key={r.slot}>
            <span className="icon"><InstrumentIcon slot={r.icon} size={22} /></span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="name">{r.slot}</div>
              <div className="meta">
                {isTarget ? "→ incoming" : isAssigned ? assigned[r.slot] : "empty"}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ---------- Cursor + drag stack helpers ----------

function Cursor({ x, y }) {
  return (
    <div className="cursor" style={{ left: x, top: y }}>
      <svg width="18" height="22" viewBox="0 0 18 22">
        <path d="M2 2 L2 18 L6 14 L9 20 L11 19 L8 13 L14 13 Z" fill="#1a1a1a" stroke="#fafaf7" strokeWidth="1" />
      </svg>
    </div>
  );
}

function DragStack({ count, x, y, label = "PDFs" }) {
  const cards = Math.min(count, 4);
  return (
    <div className="drag-stack" style={{ left: x, top: y }}>
      {Array.from({ length: cards }).map((_, i) => (
        <div key={i} className="drag-card" style={{ left: i * 4, top: i * 4, opacity: 1 - i * 0.12 }}>
          {i === 0 ? `${count} files` : ""}
        </div>
      ))}
      <div style={{ position: "absolute", left: cards * 4 + 14, top: cards * 4 + 30, fontFamily: "var(--hand)", color: "var(--accent)", fontSize: 16 }}>
        {count} {label}
      </div>
    </div>
  );
}

// ---------- Routing review table ----------

function ConfBars({ level }) {
  // level: 0..3
  const bars = [0, 1, 2].map((i) => {
    const on = i < level;
    const cls = "bar" + (on ? " on" : "") + (level === 1 && on ? " warn" : "");
    return <span key={i} className={cls} />;
  });
  return <div className="conf">{bars}<span style={{ marginLeft: 6 }}>{["—", "low", "med", "high"][level]}</span></div>;
}

function ReviewTable({ rows, onChangeRow, showHead = true }) {
  return (
    <div className="review-table">
      {showHead && (
        <div className="row head">
          <span />
          <span>File</span>
          <span />
          <span>Goes to</span>
          <span>Confidence</span>
          <span>Kind</span>
        </div>
      )}
      {rows.map((r, i) => (
        <div className={"row" + (r.unsure ? " unsure" : "")} key={i}>
          <span style={{ color: "var(--ink-2)" }}>
            <InstrumentIcon slot={r.unsure ? "unknown" : r.icon || r.slot} size={18} />
          </span>
          <span className="file" title={r.file}>{r.file}</span>
          <span className="arrow">→</span>
          <span className="target">
            {r.unsure ? (
              <select onChange={(e) => onChangeRow && onChangeRow(i, e.target.value)} defaultValue="">
                <option value="" disabled>pick a slot…</option>
                {ROSTER.filter((x) => x.role !== "score").map((x) => <option key={x.slot}>{x.slot}</option>)}
              </select>
            ) : (
              <>
                <span style={{ fontWeight: 500 }}>{r.slot}</span>
                <span className="chip guess">change</span>
              </>
            )}
          </span>
          <ConfBars level={r.unsure ? 1 : (r.conf ?? 3)} />
          <span className="mono" style={{ fontSize: 11, display: "flex", alignItems: "center", gap: 6 }}>
            <input type="checkbox" defaultChecked={r.kind === "score"} style={{ accentColor: "#1a1a1a" }} disabled={r.locked} />
            score
          </span>
        </div>
      ))}
    </div>
  );
}

// ---------- Banner / hint ----------

function Banner({ kind = "info", children }) {
  return <div className={"banner" + (kind ? " " + kind : "")}>{children}</div>;
}

// Export to window
Object.assign(window, {
  AppBar, Sidebar, ChartHeader, PartsList, DropZone,
  SlotGrid, Cursor, DragStack, ReviewTable, Banner, ConfBars
});
