// Frame components for the expanded brief.

const FILE_MAP = {
  cello: "cello.pdf",
  vln1: "violin1_v1.pdf",
  viola: "viola_v1.pdf",
  score: "lunar-noon-score_v3.pdf",
};

// ---------- 1. Resting state ----------
function FrameResting() {
  const parts = [
    { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score.pdf", versionsCount: 3, statusLabel: "v3 · changed", statusKind: "changed", historyBadge: true },
    { slot: "Cello", icon: "cello", file: "cello.pdf", versionsCount: 1 },
    { slot: "Violin 1", icon: "violin", file: "violin1_v3.pdf", versionsCount: 3, statusLabel: "v3 · changed", statusKind: "changed", historyBadge: true },
    { slot: "Viola", icon: "viola", file: "viola_v3.pdf", versionsCount: 3, statusLabel: "v3 · changed", statusKind: "changed", historyBadge: true },
  ];
  return (
    <div className="frame wf">
      <AppBar
        ensemble="String Trio + Score"
        role="director"
        otherEnsembles={[
          { name: "Tuesday Night Big Band", role: "member" },
          { name: "Saturday Quartet", role: "member" },
        ]}
      />
      <div className="app-shell">
        <ChamberSidebar />
        <div className="main">
          <div className="main-inner">
            <ChartHeaderV2 version="v3" versions={["v3", "v2", "v1"]} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
              <h2 className="section">Parts</h2>
              <span className="mono dim" style={{ fontSize: 11 }}>4 parts · history affordance per row</span>
            </div>
            <PartsListV2 parts={parts} />
            <DropZone />
            <div className="mono dim" style={{ fontSize: 11, marginTop: -4 }}>
              Tip — drop PDFs anywhere to add or update. Unchanged parts carry forward.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 2. Tray mid-drag — Scenario 2 (cello carries fwd, vln1+viola new) ----------
function FrameTrayMidDrag({ openMig = -1 }) {
  const v1Parts = [
    { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score.pdf", versionsCount: 1 },
    { slot: "Cello", icon: "cello", file: "cello.pdf", versionsCount: 1, statusLabel: "carries forward", statusKind: "" },
    { slot: "Violin 1", icon: "violin", file: "—", versionsCount: 0, statusLabel: "incoming", statusKind: "added" },
    { slot: "Viola", icon: "viola", file: "—", versionsCount: 0, statusLabel: "incoming", statusKind: "added" },
  ];
  const trayFiles = [
    { file: "violin1.pdf", size: "1.2 MB", slot: "Violin 1", icon: "violin", migration: "Cello · v1" },
    { file: "viola.pdf", size: "1.1 MB", slot: "Viola", icon: "viola", migration: "Cello · v1" },
  ];
  return (
    <div className="frame wf" style={{ position: "relative" }}>
      <AppBar
        ensemble="String Trio + Score"
        role="director"
        otherEnsembles={[
          { name: "Tuesday Night Big Band", role: "member" },
          { name: "Saturday Quartet", role: "member" },
        ]}
      />
      <div className="app-shell">
        <ChamberSidebar />
        <div className="main">
          <div className="main-inner">
            <ChartHeaderV2 version="v1" versions={["v1"]} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
              <h2 className="section">Parts</h2>
              <span className="mono dim" style={{ fontSize: 11 }}>v2 will be created</span>
            </div>
            <PartsListV2 parts={v1Parts} />
            <UploadTray files={trayFiles} openIndex={openMig} version="v2" />
            {openMig >= 0 && <MigrationPicker x={620} y={openMig === 0 ? 432 : 484} partLabel={trayFiles[openMig].slot} />}
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 3a. Per-file migration picker (A: inline) ----------
function FrameMigInline() { return <FrameTrayMidDrag openMig={0} />; }

// ---------- 3b. Per-file migration picker (B: separate step) ----------
function FrameMigSeparate() {
  const trayFiles = [
    { file: "violin1.pdf", size: "1.2 MB", slot: "Violin 1", icon: "violin" },
    { file: "viola.pdf", size: "1.1 MB", slot: "Viola", icon: "viola" },
  ];
  const migrationRows = [
    { slot: "Violin 1", icon: "violin", source: "Cello · v1", count: "3 annotations" },
    { slot: "Viola", icon: "viola", source: "Cello · v1", count: "3 annotations" },
  ];
  return (
    <div className="frame wf">
      <AppBar
        ensemble="String Trio + Score"
        role="director"
        otherEnsembles={[
          { name: "Tuesday Night Big Band", role: "member" },
          { name: "Saturday Quartet", role: "member" },
        ]}
      />
      <div className="app-shell">
        <ChamberSidebar />
        <div className="main">
          <div className="main-inner">
            <ChartHeaderV2 version="v1" versions={["v1"]} />
            <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: -6 }}>
              <span className="step-pill done">1 · Slots</span>
              <span className="step-pill cur">2 · Migrations</span>
              <span className="step-pill">3 · Publish</span>
            </div>
            <h2 className="section" style={{ marginBottom: 0 }}>Configure migrations</h2>
            <p className="mono dim" style={{ fontSize: 12, marginTop: 4 }}>
              For each new part, choose where to seed annotations from. Defaults applied.
            </p>
            <div className="migration-step">
              {migrationRows.map((r, i) => (
                <div key={i} className="mig-row">
                  <div className="mig-target">
                    <InstrumentIcon slot={r.icon} size={22} />
                    <span style={{ fontWeight: 500 }}>{r.slot}</span>
                  </div>
                  <span className="mono dim" style={{ fontSize: 14 }}>←</span>
                  <button className="mig-btn open" style={{ width: 220 }}>
                    <InstrumentIcon slot="cello" size={16} />
                    <span style={{ marginLeft: 6, fontWeight: 500 }}>{r.source}</span>
                    <span className="dim mono" style={{ marginLeft: "auto" }}>▾</span>
                  </button>
                  <span className="mono dim" style={{ fontSize: 11 }}>{r.count}</span>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button className="btn ghost">Back</button>
              <button className="btn">Publish v2</button>
            </div>
            <div className="callout">
              <div className="mono dim" style={{ fontSize: 11, letterSpacing: "0.05em", marginBottom: 4 }}>TRADE-OFF</div>
              Separates concerns cleanly but adds a step. Inline (A) is faster for the common case; this surface is better when migrations are unusual or many.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 4. Score upload (deprioritized — score is just another part) ----------
function FrameScoreUpload() {
  const trayFiles = [
    { file: "violin1.pdf", size: "1.2 MB", slot: "Violin 1", icon: "violin", migration: "Cello · v1" },
    { file: "viola.pdf", size: "1.1 MB", slot: "Viola", icon: "viola", migration: "Cello · v1" },
    { file: "lunar-noon-full-score.pdf", size: "3.4 MB", slot: "Score", icon: "score", kind: "score", migration: "—" },
  ];
  return (
    <div className="frame wf">
      <AppBar
        ensemble="String Trio + Score"
        role="director"
        otherEnsembles={[
          { name: "Tuesday Night Big Band", role: "member" },
          { name: "Saturday Quartet", role: "member" },
        ]}
      />
      <div className="app-shell">
        <ChamberSidebar />
        <div className="main">
          <div className="main-inner">
            <ChartHeaderV2 version="v1" versions={["v1"]} />
            <h2 className="section">Upload · 3 files</h2>
            <p className="mono dim" style={{ fontSize: 12, marginTop: -6 }}>
              The score sits in the tray with the parts. Same routing, same migration picker. The "score" checkbox is the only thing that distinguishes it.
            </p>
            <UploadTray files={trayFiles} version="v2" />
            <div className="callout">
              <div className="mono dim" style={{ fontSize: 11, letterSpacing: "0.05em", marginBottom: 4 }}>NOTE — SCORE ISN'T SACRED</div>
              Earlier rev gave the score its own preview pane and clarifying-questions block. Removed. Score is just a part with a checkbox; preview can live behind the filename click like any other PDF.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 5. Publish confirmation (quiet — not a celebration moment) ----------
function FramePublishConfirm() {
  const parts = [
    { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score.pdf", versionsCount: 1, statusLabel: "", statusKind: "" },
    { slot: "Cello", icon: "cello", file: "cello.pdf", versionsCount: 1, statusLabel: "carried forward", statusKind: "" },
    { slot: "Violin 1", icon: "violin", file: "violin1.pdf", versionsCount: 1, statusLabel: "v2 · added", statusKind: "added", historyBadge: true },
    { slot: "Viola", icon: "viola", file: "viola.pdf", versionsCount: 1, statusLabel: "v2 · added", statusKind: "added", historyBadge: true },
  ];
  return (
    <div className="frame wf">
      <AppBar
        ensemble="String Trio + Score"
        role="director"
        otherEnsembles={[
          { name: "Tuesday Night Big Band", role: "member" },
          { name: "Saturday Quartet", role: "member" },
        ]}
      />
      <div className="app-shell">
        <ChamberSidebar />
        <div className="main">
          <div className="main-inner">
            <ChartHeaderV2 version="v2" versions={["v2", "v1"]} />
            <div className="quiet-banner">
              <span className="mono" style={{ fontSize: 11, letterSpacing: "0.05em" }}>v2 → LIVE</span>
              <span style={{ fontSize: 13 }}>2 added · 1 carried forward · 6 annotations seeded</span>
              <span style={{ flex: 1 }} />
              <button className="btn ghost sm">undo</button>
              <button className="btn ghost sm">view diff</button>
              <span className="dim mono" style={{ fontSize: 10, paddingLeft: 8, borderLeft: "1px solid var(--line-2)" }}>auto-dismisses in 8s</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
              <h2 className="section">Parts</h2>
              <span className="mono dim" style={{ fontSize: 11 }}>director returns to the chart, not a celebration page</span>
            </div>
            <PartsListV2 parts={parts} />
            <div className="callout">
              <div className="mono dim" style={{ fontSize: 11, letterSpacing: "0.05em", marginBottom: 4 }}>NOTE — OPTIONAL MOMENT</div>
              Andrew flagged this isn't crucial. So: confirm via a thin banner over the existing chart page, no full-screen celebration. Director is right back where they were, with the new parts already visible.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 6. Player view + migration banner ----------
function PlayerView({ variant = "persistent" }) {
  return (
    <div style={{ background: "#0a0a0a", padding: 24, height: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div className="ipad" style={{ width: "94%", height: "94%", margin: 0 }}>
        <div className="ipad-screen">
          <div className="ipad-bar">
            <span className="mono">‹ Lunar Noon</span>
            <span className="dim mono">·</span>
            <InstrumentIcon slot="violin" size={16} />
            <b style={{ fontSize: 13 }}>Violin 1 · v2</b>
            <span style={{ flex: 1 }} />
            <span className="mono dim">opened by Marta</span>
          </div>
          {variant === "persistent" ? (
            <div className="migration-banner">
              <span style={{ color: "var(--accent)" }}>↳</span>
              <span className="label">3 annotations migrated from Cello · v1</span>
              <span className="dim mono" style={{ fontSize: 11 }}>marked with dashed underline</span>
              <div className="controls">
                <button className="ctrl">Keep</button>
                <button className="ctrl">Hide</button>
                <button className="ctrl">Change source</button>
                <button className="ctrl danger">Delete</button>
              </div>
            </div>
          ) : (
            <div className="migration-toast">
              <h4>3 annotations migrated</h4>
              <div className="mono dim" style={{ fontSize: 11, marginBottom: 10 }}>From Cello · v1 — Helen seeded these because the markings transfer well.</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                <button className="ctrl" style={{ border: "1px solid var(--ink)", background: "var(--paper)", padding: "4px 10px", fontSize: 12, cursor: "pointer", fontFamily: "inherit" }}>Keep all</button>
                <button className="ctrl" style={{ border: "1px solid var(--ink)", background: "var(--paper)", padding: "4px 10px", fontSize: 12, cursor: "pointer", fontFamily: "inherit" }}>Hide all</button>
                <button className="ctrl" style={{ border: "1px solid var(--ink)", background: "var(--paper)", padding: "4px 10px", fontSize: 12, cursor: "pointer", fontFamily: "inherit" }}>Review one-by-one</button>
                <button style={{ border: "1px solid var(--accent)", color: "var(--accent)", background: "var(--paper)", padding: "4px 10px", fontSize: 12, cursor: "pointer", fontFamily: "inherit" }}>Delete all</button>
              </div>
              <div className="mono dim" style={{ fontSize: 10, marginTop: 10 }}>this card won't show again</div>
            </div>
          )}
          <div className="score-stage">
            {[0, 1, 2, 3].map((i) => (
              <div className="staff" key={i}>
                <div className="staff-clef">vln 1 · m{i * 4 + 1}–{i * 4 + 4}</div>
                {[0, 1, 2, 3, 4, 5, 6].map((j) => (
                  <div key={j} className={"note-mark" + (j % 3 === 0 ? "" : " empty")} style={{ left: 80 + j * 80, top: 40 + ((j + i) % 4) * 8 }} />
                ))}
                {i === 0 && <div className="annot migrated" style={{ left: 80, top: -4 }}>cresc.</div>}
                {i === 0 && <div className="crescendo dashed" style={{ left: 80, top: 86, width: 200 }} />}
                {i === 1 && <div className="annot migrated" style={{ left: 240, top: -4 }}>watch tempo</div>}
                {i === 2 && <div className="annot" style={{ left: 200, top: -4, color: "var(--ink-2)" }}>own note</div>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 7. History timeline ----------
function FrameHistory() {
  return (
    <div className="frame wf">
      <AppBar
        ensemble="String Trio + Score"
        role="director"
        otherEnsembles={[
          { name: "Tuesday Night Big Band", role: "member" },
          { name: "Saturday Quartet", role: "member" },
        ]}
      />
      <div className="app-shell">
        <ChamberSidebar />
        <div className="main">
          <div className="main-inner">
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <span className="mono dim" style={{ fontSize: 11 }}>‹ back to chart</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <InstrumentIcon slot="violin" size={28} />
              <div>
                <div className="h-eyebrow">Part history</div>
                <h1 className="title" style={{ fontSize: 22 }}>Violin 1 — Lunar Noon</h1>
              </div>
            </div>
            <div className="timeline">
              <div className="v">
                <span className="stamp">v4 <span className="date">today</span></span>
                <span className="dot ghost" />
                <div className="body">
                  <div className="summary dim">No change to Violin 1 in this version</div>
                  <div className="detail">v4 removed the Cello part. Violin 1 carried forward unchanged.</div>
                </div>
                <span className="open">view diff →</span>
              </div>
              <div className="v">
                <span className="stamp">v3 <span className="date">Apr 22</span></span>
                <span className="dot" />
                <div className="body">
                  <div className="summary">4 measures changed · 7 annotations migrated</div>
                  <div className="detail">Composer revised mm. 17–20. Marta's previous annotations were re-anchored to the new measure data; 1 stayed flagged for review.</div>
                </div>
                <span className="open">view diff →</span>
              </div>
              <div className="v">
                <span className="stamp">v2 <span className="date">Apr 18</span></span>
                <span className="dot" />
                <div className="body">
                  <div className="summary">Part created · 3 annotations migrated from Cello v1</div>
                  <div className="detail">Helen seeded crescendos and tempo markings from the cello part. Marta kept all three.</div>
                </div>
                <span className="open">view diff →</span>
              </div>
              <div className="v">
                <span className="stamp dim">v1 <span className="date">Apr 12</span></span>
                <span className="dot ghost" />
                <div className="body">
                  <div className="summary dim">Didn't exist yet</div>
                  <div className="detail">Lunar Noon v1 only had a cello part.</div>
                </div>
                <span className="open dim">—</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- 8. v4 with cello removed ----------
function FrameV4Removed() {
  const [hideRemoved, setHideRemoved] = React.useState(false);
  // Active parts first, removed parts auto-sink to the bottom.
  const parts = [
    { slot: "Score", icon: "score", kind: "score", file: "lunar-noon-score_v4.pdf", versionsCount: 4, statusLabel: "v4 · updated", statusKind: "changed", historyBadge: true },
    { slot: "Violin 1", icon: "violin", file: "violin1_v3.pdf", versionsCount: 3, statusLabel: "unchanged in v4", statusKind: "" },
    { slot: "Viola", icon: "viola", file: "viola_v3.pdf", versionsCount: 3, statusLabel: "unchanged in v4", statusKind: "" },
    { slot: "Cello", icon: "cello", file: "—", versionsCount: 3, statusLabel: "removed in v4", statusKind: "removed" },
  ];
  const removedCount = parts.filter(p => p.statusKind === "removed").length;
  return (
    <div className="frame wf">
      <AppBar
        ensemble="String Trio + Score"
        role="director"
        otherEnsembles={[
          { name: "Tuesday Night Big Band", role: "member" },
          { name: "Saturday Quartet", role: "member" },
        ]}
      />
      <div className="app-shell">
        <ChamberSidebar />
        <div className="main">
          <div className="main-inner">
            <ChartHeaderV2 version="v4" versions={["v4", "v3", "v2", "v1"]} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 12 }}>
              <h2 className="section">Parts</h2>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span className="mono dim" style={{ fontSize: 11 }}>v3 → v4 · removed Cello</span>
                <button
                  className="btn ghost sm"
                  onClick={() => setHideRemoved(v => !v)}
                  style={{ fontFamily: "'Geist Mono', monospace", fontSize: 11 }}
                >
                  {hideRemoved
                    ? `Show removed (${removedCount})`
                    : `Hide removed (${removedCount})`}
                </button>
              </div>
            </div>
            <PartsListV2 parts={parts} hideRemoved={hideRemoved} />
            <div className="callout">
              <div className="mono dim" style={{ fontSize: 11, letterSpacing: "0.05em", marginBottom: 4 }}>TWO BEHAVIORS ON THIS LIST</div>
              <b>Removed parts auto-sink</b> to the bottom of the list (struck-through, dimmed). They keep their slot and history, but get out of the active reading order.<br/>
              <b>Hide removed</b> collapses the struck-through row entirely. History stays reachable from the chart's version dropdown when collapsed.
            </div>
            <DropZone />
          </div>
        </div>
      </div>
    </div>
  );
}

window.FrameResting = FrameResting;
window.FrameTrayMidDrag = FrameTrayMidDrag;
window.FrameMigInline = FrameMigInline;
window.FrameMigSeparate = FrameMigSeparate;
window.FrameScoreUpload = FrameScoreUpload;
window.FramePublishConfirm = FramePublishConfirm;
window.PlayerView = PlayerView;
window.FrameHistory = FrameHistory;
window.FrameV4Removed = FrameV4Removed;
