// Storyboard A — Drop-on-page model
// Case #2 (many PDFs at once). 7 frames, clickable.

function StoryA({ frame = 0 }) {
  // Drag manifest
  const incoming = [
    { file: "Tpt 1.pdf", slot: "Trumpet 1", icon: "trumpet", conf: 3 },
    { file: "Trumpet_2_FINAL.pdf", slot: "Trumpet 2", icon: "trumpet", conf: 3 },
    { file: "AS1.pdf", slot: "Alto Sax 1", icon: "sax", conf: 3 },
    { file: "tenor sax v3.pdf", slot: "Tenor Sax", icon: "sax", conf: 3 },
    { file: "piano-pt.pdf", slot: "Piano", icon: "piano", conf: 3 },
    { file: "bass.pdf", slot: "Bass", icon: "bass", conf: 3 },
    { file: "drums chart.pdf", slot: "Drums", icon: "drums", conf: 3 },
    { file: "Untitled-1.pdf", slot: null, icon: "unknown", conf: 1, unsure: true },
    { file: "lunar-noon SCORE.pdf", slot: "Score", icon: "score", kind: "score", conf: 3 },
  ];

  // Frame 0 — resting (Finder hover, no drag yet)
  if (frame === 0) {
    return (
      <FrameShell
        num="01 / 07"
        caption={<><b>Resting.</b> Chart page with upload affordance visible but inactive. The director has a stack of 9 PDFs in Finder, about to drag.</>}
      >
        <BaseChart parts={[]} />
        <FinderHint />
      </FrameShell>
    );
  }

  // Frame 1 — drag enters viewport, full-page drop overlay activates
  if (frame === 1) {
    return (
      <FrameShell
        num="02 / 07"
        caption={<><b>Drag enters page.</b> The whole content area becomes the drop target. Director doesn't have to aim — the page itself is the affordance.</>}
      >
        <BaseChart parts={[]} dropFull />
        <DragStack count={9} x={420} y={250} />
        <Cursor x={460} y={264} />
      </FrameShell>
    );
  }

  // Frame 2 — release; routing review opens inline
  if (frame === 2) {
    return (
      <FrameShell
        num="03 / 07"
        caption={<><b>Release.</b> Scorva matches each PDF to a slot using filename, OMR title block, and instrument detection. The review opens <i>in place</i> — no modal, no nav.</>}
      >
        <BaseChart
          parts={[]}
          slot={
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <Banner kind="">
                <span className="mono" style={{ fontSize: 11, letterSpacing: "0.05em" }}>9 FILES · ROUTED 8 · 1 NEEDS REVIEW</span>
                <span className="dim mono" style={{ fontSize: 11, marginLeft: "auto" }}>scanning measure data…</span>
              </Banner>
              <ReviewTable rows={incoming} />
              <div style={{ display: "flex", gap: 8, justifyContent: "space-between", alignItems: "center" }}>
                <span className="mono dim" style={{ fontSize: 11 }}>fix unsure rows below, then confirm</span>
                <div style={{ display: "flex", gap: 8 }}>
                  <button className="btn ghost">Cancel</button>
                  <button className="btn" disabled>Add to v1 (1 needs review)</button>
                </div>
              </div>
            </div>
          }
        />
      </FrameShell>
    );
  }

  // Frame 3 — director fixes the unsure row from a quick popover
  if (frame === 3) {
    return (
      <FrameShell
        num="04 / 07"
        caption={<><b>Fix the unsure one.</b> Click the slot → instrument popover. Recognition cue is the icon, not the word. One click resolves it.</>}
      >
        <BaseChart
          parts={[]}
          slot={
            <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: 12 }}>
              <Banner kind="">
                <span className="mono" style={{ fontSize: 11, letterSpacing: "0.05em" }}>9 FILES · ROUTED 8 · 1 NEEDS REVIEW</span>
              </Banner>
              <ReviewTable rows={incoming} />
              {/* popover anchored on the unsure row */}
              <div className="popover" style={{ left: 360, top: 252 }}>
                <div className="head">Untitled-1.pdf — pick slot</div>
                {window.SCORVA_ROSTER.filter((r) => r.role !== "score").map((r) => (
                  <div className={"opt" + (r.slot === "Alto Sax 1" ? " cur" : "")} key={r.slot}>
                    <InstrumentIcon slot={r.icon} size={18} />
                    <span>{r.slot}</span>
                    {r.slot === "Alto Sax 1" && <span className="dim mono" style={{ marginLeft: "auto", fontSize: 10 }}>↵</span>}
                  </div>
                ))}
              </div>
              <div className="scribble" style={{ left: 600, top: 260, transform: "rotate(-3deg)" }}>
                viola? no — alto sax 1 ✓
              </div>
            </div>
          }
        />
      </FrameShell>
    );
  }

  // Frame 4 — all green; confirm enabled
  if (frame === 4) {
    const fixed = incoming.map((r) =>
      r.unsure ? { file: r.file, slot: "Alto Sax 1", icon: "sax", conf: 2 } : r
    );
    return (
      <FrameShell
        num="05 / 07"
        caption={<><b>All green.</b> Confirm primes in. Hitting Enter or clicking the button writes 9 parts to v1 in one shot.</>}
      >
        <BaseChart
          parts={[]}
          slot={
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <Banner kind="ok">
                <span className="mono" style={{ fontSize: 11, letterSpacing: "0.05em" }}>9 FILES · ALL ROUTED · READY</span>
                <span className="dim mono" style={{ fontSize: 11, marginLeft: "auto" }}>1 score detected</span>
              </Banner>
              <ReviewTable rows={fixed} />
              <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", alignItems: "center" }}>
                <span className="chip kbd">enter</span>
                <button className="btn ghost">Cancel</button>
                <button className="btn">Add 9 parts to v1</button>
              </div>
            </div>
          }
        />
      </FrameShell>
    );
  }

  // Frame 5 — landed, parts list populated
  if (frame === 5) {
    const landed = [
      { slot: "Score", icon: "score", kind: "score", file: "lunar-noon SCORE.pdf" },
      { slot: "Trumpet 1", icon: "trumpet", file: "Tpt 1.pdf" },
      { slot: "Trumpet 2", icon: "trumpet", file: "Trumpet_2_FINAL.pdf" },
      { slot: "Alto Sax 1", icon: "sax", file: "AS1.pdf" },
      { slot: "Alto Sax 1", icon: "sax", file: "Untitled-1.pdf" },
      { slot: "Tenor Sax", icon: "sax", file: "tenor sax v3.pdf" },
      { slot: "Piano", icon: "piano", file: "piano-pt.pdf" },
      { slot: "Bass", icon: "bass", file: "bass.pdf" },
      { slot: "Drums", icon: "drums", file: "drums chart.pdf" },
    ];
    return (
      <FrameShell
        num="06 / 07"
        caption={<><b>Landed.</b> Parts list populated. v1 is now complete. The drop zone returns to its resting state for the next batch.</>}
      >
        <BaseChart parts={landed} />
      </FrameShell>
    );
  }

  // Frame 6 — fix-after — wrong slot recovery (case #5)
  if (frame === 6) {
    const landed = [
      { slot: "Score", icon: "score", kind: "score", file: "lunar-noon SCORE.pdf" },
      { slot: "Trumpet 1", icon: "trumpet", file: "Tpt 1.pdf" },
      { slot: "Trumpet 2", icon: "trumpet", file: "Trumpet_2_FINAL.pdf" },
      { slot: "Alto Sax 1", icon: "sax", file: "AS1.pdf" },
      { slot: "Alto Sax 1", icon: "sax", file: "Untitled-1.pdf" },
      { slot: "Tenor Sax", icon: "sax", file: "tenor sax v3.pdf" },
      { slot: "Piano", icon: "piano", file: "piano-pt.pdf" },
      { slot: "Bass", icon: "bass", file: "bass.pdf" },
      { slot: "Drums", icon: "drums", file: "drums chart.pdf" },
    ];
    return (
      <FrameShell
        num="07 / 07"
        caption={<><b>Wrong slot, after the fact.</b> Click any row's slot to re-pick. Same popover as during routing — no separate "edit" surface to learn.</>}
      >
        <BaseChart
          parts={landed}
          slot={
            <div className="popover" style={{ left: 320, top: 200 }}>
              <div className="head">Untitled-1.pdf — re-pick slot</div>
              {window.SCORVA_ROSTER.filter((r) => r.role !== "score").map((r) => (
                <div className={"opt" + (r.slot === "Alto Sax 1" ? " cur" : "")} key={r.slot}>
                  <InstrumentIcon slot={r.icon} size={18} />
                  <span>{r.slot}</span>
                  {r.slot === "Alto Sax 1" && <span className="dim mono" style={{ marginLeft: "auto", fontSize: 10 }}>current</span>}
                </div>
              ))}
            </div>
          }
        />
        <div className="scribble" style={{ left: 380, top: 178, transform: "rotate(-2deg)" }}>
          actually viola →
        </div>
      </FrameShell>
    );
  }

  return null;
}

// Story shell with caption strip below the canvas
function FrameShell({ children, num, caption }) {
  return (
    <div className="story-shell" style={{ background: "var(--paper)" }}>
      <div className="story-canvas">{children}</div>
      <div className="story-caption">
        <span className="num mono">{num}</span>
        <span className="body">{caption}</span>
      </div>
    </div>
  );
}

// Compact chart-page used inside storyboard frames; can render an inline panel below parts list.
function BaseChart({ parts = [], dropFull = false, slot = null, version = "v1", versions = ["v1"] }) {
  return (
    <div className="frame wf" style={{ position: "relative" }}>
      <AppBar />
      <div className="app-shell">
        <Sidebar />
        <div className="main">
          <div className="main-inner">
            <ChartHeader version={version} versions={versions} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
              <h2 className="section">Parts</h2>
              <span className="mono dim" style={{ fontSize: 11 }}>
                {parts.length} of 8 slots filled
              </span>
            </div>
            <PartsList parts={parts} />
            {slot ? slot : <DropZone />}
          </div>
        </div>
      </div>
      {dropFull && <DropZone full />}
    </div>
  );
}

function FinderHint() {
  return (
    <>
      <div
        style={{
          position: "absolute",
          right: 26,
          top: 110,
          width: 220,
          background: "var(--paper)",
          border: "1.5px solid var(--line)",
          boxShadow: "3px 3px 0 rgba(0,0,0,0.08)",
          padding: 10,
          fontFamily: "Geist Mono, ui-monospace, monospace",
          fontSize: 11,
          zIndex: 50,
        }}
      >
        <div className="dim" style={{ fontSize: 10, marginBottom: 6 }}>FINDER · 9 ITEMS</div>
        {["Tpt 1.pdf","Trumpet_2_FINAL.pdf","AS1.pdf","tenor sax v3.pdf","piano-pt.pdf","bass.pdf","drums chart.pdf","Untitled-1.pdf","lunar-noon SCORE.pdf"].map((f) => (
          <div key={f} style={{ padding: "2px 0", color: "var(--ink-2)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            ▢ {f}
          </div>
        ))}
      </div>
      <div className="scribble" style={{ right: 260, top: 220, transform: "rotate(-4deg)" }}>
        9 PDFs<br/>about to drag →
      </div>
    </>
  );
}

window.StoryA = StoryA;
window.FrameShell = FrameShell;
window.BaseChart = BaseChart;
