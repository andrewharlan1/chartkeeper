/* global React, InstrumentIcon */
// ============================================================
// Scorva HI-FI shared shell + chrome
// AppBar (top), Sidebar (left), TopBar/Crumbs.
// ============================================================

function HfSidebar({ ensemble = "String Trio + Score", chart = "Lunar Noon" }) {
  return (
    <div className="hf-sidebar">
      <div className="brand">
        <div className="mark">S</div>
        <div className="name">Scorva</div>
      </div>

      <div className="group">Workspace</div>
      <div className="item">
        <span className="dot" /> Helen Aoki
      </div>

      <div className="group">Ensembles</div>
      <div className="item active">
        <span className="dot live" /> {ensemble}
      </div>
      <div className="item sub">Roster · 3 players</div>
      <div className="item">
        <span className="dot" /> Tuesday Night Big Band
      </div>
      <div className="item">
        <span className="dot" /> Saturday Quartet
      </div>

      <div className="group">Charts · {ensemble.split(" ")[0]} {ensemble.split(" ")[1] || ""}</div>
      <div className={"item sub " + (chart === "Lunar Noon" ? "cur" : "")}>· Lunar Noon</div>
      <div className="item sub">· Equinox</div>
      <div className="item sub">· Open Air (draft)</div>

      <div className="footer">
        <div className="avatar">HA</div>
        <div>
          <div style={{ color: "var(--ink)", fontWeight: 500, fontSize: 12.5 }}>Helen Aoki</div>
          <div style={{ fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-4)" }}>director</div>
        </div>
      </div>
    </div>);

}

function HfTopBar({ ensemble = "String Trio + Score", chart = "Lunar Noon", trail, right }) {
  return (
    <div className="hf-topbar">
      <div className="hf-crumbs">
        <span>{ensemble}</span>
        <span className="sep">/</span>
        <span className={trail ? "" : "cur"}>{chart}</span>
        {trail && <span className="sep">/</span>}
        {trail && <span className="cur">{trail}</span>}
      </div>
      <div className="spacer" />
      {right}
    </div>);

}

function ChartHead({
  version = "v3",
  versions = ["v3", "v2", "v1"],
  partsCount = 3,
  optName = "",
  rightActions,
  whenText = "pushed Tue · 4 measures changed in Vln 1",
  working = false
}) {
  return (
    <div className="chart-head">
      <div className="left">
        <div className="eyebrow">Chart · String Trio + Score</div>
        <h1>Lunar Noon</h1>
        <div className="meta">
          <span className={"ver-pill" + (working ? " working" : "")}>
            <span className="dot" /> {version} <span className="dim">·</span> {working ? "working" : "live"}
          </span>
          <span>{partsCount} parts</span>
          <span style={{ color: "var(--ink-4)" }}>·</span>
          <span>{whenText}</span>
        </div>
      </div>
      <div className="right">{rightActions}</div>
    </div>);

}

// ----- Status pill that maps a v2 statusKind to hi-fi spill -----
function StatusPill({ kind, label }) {
  if (!label) return <span className="spill carried"><span className="dot" /> unchanged</span>;
  return <span className={"spill " + (kind || "")} style={{ color: "rgb(181, 130, 0)" }}><span className="dot" />{label}</span>;
}

// ----- Drop zone (resting) -----
function DropZone({ active = false, label = "Drop PDFs here, or click to choose" }) {
  return (
    <div className={"dropzone" + (active ? " active" : "")}>
      <span className="arrow">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M8 2 L8 11 M4 7 L8 11 L12 7" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M2 13 L14 13" strokeLinecap="round" />
        </svg>
      </span>
      <span>{label}</span>
      <span className="kbd">⌘ U</span>
    </div>);

}

// ----- HistoryButton -----
function HistoryButton({ versionsCount = 1, badged = false }) {
  return (
    <button className={"history-btn" + (badged ? " badged" : "")} title="Open version history">
      <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
        <circle cx="8" cy="8" r="6" />
        <path d="M8 4 L8 8 L11 9.5" strokeLinecap="round" />
      </svg>
      <span>v{versionsCount}</span>
      {badged && <span className="badge" />}
    </button>);

}

// ----- Parts list (hi-fi) -----
function HfPartsList({ parts, onOpen }) {
  // Removed parts auto-sink to bottom.
  const sorted = [...parts].sort((a, b) => {
    const ar = a.statusKind === "removed" ? 1 : 0;
    const br = b.statusKind === "removed" ? 1 : 0;
    return ar - br;
  });
  return (
    <div className="parts-card">
      <div className="ph">
        <span></span>
        <span>Part</span>
        <span>Status in this version</span>
        <span>Migration source</span>
        <span>History</span>
      </div>
      {sorted.map((p, i) =>
      <div
        className={
        "part-row " + (
        p.statusKind === "removed" ? "removed " : "") + (
        p.kind === "score" ? "score-row " : "")
        }
        key={p.slot}
        onClick={() => onOpen && onOpen(p.slot)}>
        
          <span className="icon-cell">
            <InstrumentIcon slot={p.icon || p.slot} size={22} />
          </span>
          <span className="name-cell">
            <span className="name">
              {p.slot}
              {p.kind === "score" && <span className="score-tag">Score</span>}
            </span>
            <span className="filename">{p.file || "—"}</span>
          </span>
          <span className="status-cell">
            <StatusPill kind={p.statusKind} label={p.statusLabel} />
          </span>
          <span className="versions-cell">
            {p.migrationSource || <span className="dim">—</span>}
          </span>
          <span style={{ display: "flex", justifyContent: "flex-end" }}>
            <HistoryButton versionsCount={p.versionsCount} badged={p.historyBadge} />
          </span>
        </div>
      )}
    </div>);

}

window.HfSidebar = HfSidebar;
window.HfTopBar = HfTopBar;
window.ChartHead = ChartHead;
window.StatusPill = StatusPill;
window.DropZone = DropZone;
window.HistoryButton = HistoryButton;
window.HfPartsList = HfPartsList;