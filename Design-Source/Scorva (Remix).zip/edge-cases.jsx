// Edge-case mini-frames: #1 fresh chart, #4 score detection, plus a clickable focus prototype.

// Case #1: One PDF onto a fresh chart
function CaseFresh({ frame = 0 }) {
  const empty = [];
  if (frame === 0) {
    return (
      <FrameShell num="case 1 · 01 / 03" caption={<><b>Fresh chart.</b> No parts yet. Single cello PDF mid-drag.</>}>
        <BaseChart parts={empty} />
        <DragStack count={1} x={520} y={300} label="PDF" />
        <Cursor x={560} y={314} />
      </FrameShell>
    );
  }
  if (frame === 1) {
    return (
      <FrameShell num="case 1 · 02 / 03" caption={<><b>Single-file shortcut.</b> When only one file drops AND we're confident, skip the table. Show one card, one verdict, one button.</>}>
        <BaseChart
          parts={empty}
          slot={
            <div style={{ border: "1px solid var(--line-2)", background: "var(--paper)", padding: 18 }}>
              <div className="mono dim" style={{ fontSize: 11, marginBottom: 12 }}>1 FILE · ROUTED</div>
              <div style={{ display: "flex", alignItems: "center", gap: 14, fontSize: 14 }}>
                <span className="file-card" style={{ padding: "10px 14px" }}>
                  <InstrumentIcon slot="cello" size={22} />
                  <span className="name">Cello.pdf</span>
                </span>
                <span className="mono dim" style={{ fontSize: 18 }}>→</span>
                <span style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px 14px", border: "1px solid var(--line-2)" }}>
                  <InstrumentIcon slot="cello" size={22} />
                  <span style={{ fontWeight: 500 }}>Cello</span>
                </span>
                <span className="chip guess" style={{ marginLeft: 8 }}>change</span>
              </div>
              <div style={{ marginTop: 16, display: "flex", justifyContent: "flex-end", gap: 8 }}>
                <button className="btn ghost">Cancel</button>
                <button className="btn">Add to v1</button>
              </div>
            </div>
          }
        />
      </FrameShell>
    );
  }
  if (frame === 2) {
    const landed = [{ slot: "Cello", icon: "cello", file: "Cello.pdf" }];
    return (
      <FrameShell num="case 1 · 03 / 03" caption={<><b>Landed.</b> One row in the parts list. The other 7 slots stay empty (visible in the slot strip below if shown).</>}>
        <BaseChart parts={landed} />
      </FrameShell>
    );
  }
  return null;
}

// Case #4: Score
function CaseScore({ frame = 0 }) {
  if (frame === 0) {
    return (
      <FrameShell num="case 4 · 01 / 02" caption={<><b>Score detection.</b> Filename "SCORE", multi-stave page, and full-bandwidth measure data → routed to the Score slot. <i>Score</i> toggle on the row makes correction trivial when wrong.</>}>
        <BaseChart
          parts={[]}
          slot={
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <Banner kind="">
                <span className="mono" style={{ fontSize: 11, letterSpacing: "0.05em" }}>2 FILES · 1 SCORE · 1 PART</span>
              </Banner>
              <ReviewTable rows={[
                { file: "lunar-noon SCORE.pdf", slot: "Score", icon: "score", kind: "score", conf: 3 },
                { file: "tpt1.pdf", slot: "Trumpet 1", icon: "trumpet", conf: 3 },
              ]} />
            </div>
          }
        />
      </FrameShell>
    );
  }
  if (frame === 1) {
    return (
      <FrameShell num="case 4 · 02 / 02" caption={<><b>Wrong about score.</b> If a regular part PDF gets misread as score, untick the score box on its row — it falls back to a normal slot pick.</>}>
        <BaseChart
          parts={[]}
          slot={
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <Banner kind="">
                <span className="mono" style={{ fontSize: 11, letterSpacing: "0.05em" }}>1 FILE · MISCLASSIFIED?</span>
              </Banner>
              <ReviewTable rows={[
                { file: "piano-full.pdf", slot: "Score", icon: "score", kind: "score", conf: 2 },
              ]} />
              <div className="scribble" style={{ position: "relative", marginTop: -4, transform: "rotate(-2deg)", color: "var(--accent)", fontSize: 16 }}>
                untick "score" → falls back to slot pick
              </div>
            </div>
          }
        />
      </FrameShell>
    );
  }
  return null;
}

// ---------- Clickable focus prototype: full Story A flow with prev/next ----------

function ClickableA() {
  const [frame, setFrame] = React.useState(0);
  const total = 7;

  React.useEffect(() => {
    const handler = (e) => {
      if (e.key === "ArrowRight") setFrame((f) => Math.min(total - 1, f + 1));
      if (e.key === "ArrowLeft") setFrame((f) => Math.max(0, f - 1));
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <div style={{ position: "relative", height: "100%", display: "flex", flexDirection: "column" }}>
      <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
        <StoryA frame={frame} />
      </div>
      {/* Floating scrubber */}
      <div
        style={{
          position: "absolute",
          left: 0, right: 0, bottom: 0,
          padding: "10px 14px",
          background: "var(--paper-2)",
          borderTop: "1px solid var(--line)",
          display: "flex",
          alignItems: "center",
          gap: 12,
          fontSize: 12,
          fontFamily: "Geist Mono, ui-monospace, monospace",
          zIndex: 100,
        }}
      >
        <button className="btn sm ghost" onClick={() => setFrame((f) => Math.max(0, f - 1))} disabled={frame === 0}>← prev</button>
        <button className="btn sm ghost" onClick={() => setFrame((f) => Math.min(total - 1, f + 1))} disabled={frame === total - 1}>next →</button>
        <span className="dim">frame {frame + 1} / {total}</span>
        <div style={{ flex: 1 }} />
        <span className="dim">← / → keys</span>
        {Array.from({ length: total }).map((_, i) => (
          <span
            key={i}
            onClick={() => setFrame(i)}
            style={{
              width: 22, height: 6,
              background: i === frame ? "var(--ink)" : "var(--line-2)",
              cursor: "pointer",
            }}
          />
        ))}
      </div>
    </div>
  );
}

window.CaseFresh = CaseFresh;
window.CaseScore = CaseScore;
window.ClickableA = ClickableA;
